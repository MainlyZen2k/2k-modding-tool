/*
 * modloader.cpp - reference "Advanced Features" loader for a modded
 * NBA 2K20 mobile APK (personal, offline use only).
 *
 * This is the reference implementation of the mechanism the community
 * modded APKs use (their libfuck.so + assets/Advanced Features/*.txt):
 *
 *   1. A small native library is loaded by the game process
 *      (smali edit: System.loadLibrary("modloader") inside the game's
 *      Application subclass, or a constructor attribute below when the
 *      lib is added to the APK and loaded from a hooked class).
 *   2. At load time it locates the game library
 *      (libnba2k20_clean_opt.so) by parsing /proc/self/maps.
 *   3. It reads patch profiles: name|0xoffset|type|value
 *      (exactly the format 2K20 Mod Studio exports) from
 *      /sdcard/ModStudio/patches/*.patch
 *   4. For each entry it mprotect()s the target page and memcpy()s the
 *      value - the same write GameGuardian would do, done once at launch.
 *
 * Build (NDK):
 *   ndk-build with the included Android.mk, or:
 *   clang -shared -o libmodloader.so modloader.cpp -llog
 *
 * WARNING: offsets are lib-build specific (the community tables target
 * libnba2k20_clean_opt.so 98.0.2). Wrong writes crash the game.
 * Offline use only - never online.
 */

#include <android/log.h>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <vector>

#define LOG_TAG "ModStudioLoader"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static const char* GAME_LIB = "libnba2k20_clean_opt.so";
static const char* PATCH_DIR = "/sdcard/ModStudio/patches";

struct Patch {
    std::string name;
    uintptr_t offset;
    std::string type;   // byte | word | dword | float
    long long   ivalue;
    float       fvalue;
};

// find base address of the game lib from /proc/self/maps
static uintptr_t findLibBase(const char* libName, size_t* outSize) {
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    char line[1024];
    uintptr_t base = 0;
    uintptr_t end = 0;
    while (fgets(line, sizeof(line), f)) {
        char* p = strstr(line, libName);
        if (!p) continue;
        uintptr_t start = strtoull(line, nullptr, 16);
        const char* dash = strchr(line, '-');
        if (dash) end = strtoull(dash + 1, nullptr, 16);
        if (base == 0) base = start;
        if (end > base) { /* keep last mapping for size */ }
        // continue until the last mapping of this lib
        base = (base == 0) ? start : base;
    }
    fclose(f);
    if (outSize && end > base) *outSize = end - base;
    return base;
}

static bool parsePatchLine(const std::string& line, Patch& p) {
    // name|0xoffset|type|value
    size_t p1 = line.find('|');
    if (p1 == std::string::npos) return false;
    size_t p2 = line.find('|', p1 + 1);
    if (p2 == std::string::npos) return false;
    size_t p3 = line.find('|', p2 + 1);
    if (p3 == std::string::npos) return false;
    p.name = line.substr(0, p1);
    std::string offHex = line.substr(p1 + 1, p2 - p1 - 1);
    p.type = line.substr(p2 + 1, p3 - p2 - 1);
    std::string val = line.substr(p3 + 1);
    if (offHex.rfind("0x", 0) == 0 || offHex.rfind("0X", 0) == 0) offHex = offHex.substr(2);
    p.offset = strtoull(offHex.c_str(), nullptr, 16);
    p.ivalue = 0; p.fvalue = 0;
    if (p.type == "float") p.fvalue = strtof(val.c_str(), nullptr);
    else p.ivalue = strtoll(val.c_str(), nullptr, val.rfind("0x", 0) == 0 ? 16 : 10);
    return !p.name.empty() && p.offset != 0;
}

static std::vector<Patch> loadProfiles() {
    std::vector<Patch> patches;
    DIR* d = opendir(PATCH_DIR);
    if (!d) { LOGI("no patch dir %s", PATCH_DIR); return patches; }
    struct dirent* e;
    while ((e = readdir(d)) != nullptr) {
        std::string fn = e->d_name;
        if (fn.length() < 6 || fn.substr(fn.length() - 6) != ".patch") continue;
        std::string full = std::string(PATCH_DIR) + "/" + fn;
        FILE* f = fopen(full.c_str(), "r");
        if (!f) continue;
        char buf[512];
        int count = 0;
        while (fgets(buf, sizeof(buf), f)) {
            std::string line(buf);
            // trim
            while (!line.empty() && (line.back() == '\n' || line.back() == '\r' || line.back() == ' '))
                line.pop_back();
            if (line.empty() || line[0] == '#') continue;
            Patch p;
            if (parsePatchLine(line, p)) { patches.push_back(p); count++; }
        }
        fclose(f);
        LOGI("loaded %d patches from %s", count, fn.c_str());
    }
    closedir(d);
    return patches;
}

static void applyPatch(uintptr_t base, const Patch& p) {
    void* addr = reinterpret_cast<void*>(base + p.offset);
    long pageSize = sysconf(_SC_PAGESIZE);
    uintptr_t page = reinterpret_cast<uintptr_t>(addr) & ~(uintptr_t)(pageSize - 1);
    size_t len = p.type == "byte" ? 1 : (p.type == "word" ? 2 : 4);
    if (mprotect((void*)page, pageSize, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        LOGE("mprotect failed for %s: %s", p.name.c_str(), strerror(errno));
        return;
    }
    if (p.type == "float") {
        float v = p.fvalue;
        memcpy(addr, &v, 4);
        LOGI("%s -> %f (float @0x%lx)", p.name.c_str(), v, p.offset);
    } else if (p.type == "byte") {
        unsigned char v = (unsigned char)(p.ivalue & 0xFF);
        memcpy(addr, &v, 1);
        LOGI("%s -> %u (byte @0x%lx)", p.name.c_str(), v, p.offset);
    } else if (p.type == "word") {
        unsigned short v = (unsigned short)(p.ivalue & 0xFFFF);
        memcpy(addr, &v, 2);
        LOGI("%s -> %u (word @0x%lx)", p.name.c_str(), v, p.offset);
    } else { // dword
        unsigned int v = (unsigned int)(p.ivalue & 0xFFFFFFFFu);
        memcpy(addr, &v, 4);
        LOGI("%s -> %u (dword @0x%lx)", p.name.c_str(), v, p.offset);
    }
}

static void applyAll() {
    size_t libSize = 0;
    uintptr_t base = findLibBase(GAME_LIB, &libSize);
    if (base == 0) { LOGE("game lib not mapped yet"); return; }
    LOGI("game lib base: 0x%lx size: %zu", base, libSize);
    std::vector<Patch> patches = loadProfiles();
    for (const Patch& p : patches) {
        if (p.offset < libSize) applyPatch(base, p);
        else LOGE("skip %s: offset 0x%lx out of range", p.name.c_str(), p.offset);
    }
}

// Apply as soon as this lib is dlopen'ed. Wire it by adding
// System.loadLibrary("modloader") to a hooked class in the game APK,
// or by using an injector of your choice.
__attribute__((constructor))
static void modloaderInit() {
    LOGI("2K20 Mod Studio loader starting (offline use only)");
    applyAll();
}
