package com.modstudio.twok20.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.modstudio.twok20.core.DdsCodec;
import com.modstudio.twok20.core.FileDirs;
import com.modstudio.twok20.core.IffPatch;
import com.modstudio.twok20.core.IffSniffer;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/**
 * Texture Studio: inspect IFF containers, extract / retexture DDS payloads
 * with quality presets, and build 512x512 white face maps for cyberface
 * porting (the 2K14 -> 2K20 mobile workflow).
 */
public class TextureActivity extends Activity {

    private static final int PICK_SOURCE = 101;
    private static final int PICK_PNG = 102;
    private static final int PICK_FACE_PNG = 103;
    private static final String[] PRESETS = {
            "Original size", "HD 1024", "High HD 2048", "Ultra HD 4096", "Half size"
    };

    private File srcFile;
    private IffSniffer.Result scan;
    private IffSniffer.Asset selectedAsset;
    private DdsCodec.Info selectedInfo;
    private String pngPath;

    private TextView srcInfo;
    private LinearLayout assetsBox;
    private TextView pickPngLabel;
    private Spinner presetSpin;
    private CheckBox flipCheck, mipsCheck;
    private EditText faceId;
    private CheckBox faceFlip;
    private TextView resultView;

    private final FileDirs dirs = new FileDirs();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = CommonUi.scroll(this);
        LinearLayout root = CommonUi.column(this, 12);

        root.addView(CommonUi.title(this, "Texture Studio"));
        root.addView(CommonUi.dim(this,
                "Workflow: pick an IFF extracted from the game APK (or a raw DDS), "
                + "select a texture payload, import your PNG and export the retextured file. "
                + "Same-size swaps keep the container valid."));

        // source card
        LinearLayout srcCard = CommonUi.card(this);
        srcCard.addView(CommonUi.label(this, "1. Source file (IFF / DDS)"));
        Button pickSrc = CommonUi.button(this, "Pick IFF / DDS file");
        pickSrc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { pick(PICK_SOURCE); }
        });
        srcCard.addView(pickSrc);
        srcInfo = CommonUi.dim(this, "No source picked.");
        srcCard.addView(srcInfo);
        root.addView(srcCard);

        // assets card
        LinearLayout assetsCard = CommonUi.card(this);
        assetsCard.addView(CommonUi.label(this, "2. Embedded payloads"));
        assetsBox = CommonUi.column(this);
        assetsCard.addView(assetsBox);
        root.addView(assetsCard);

        // retexture card
        LinearLayout retexCard = CommonUi.card(this);
        retexCard.addView(CommonUi.label(this, "3. Retexture (PNG -> DDS)"));
        Button pickPng = CommonUi.buttonGhost(this, "Pick replacement PNG");
        pickPng.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { pick(PICK_PNG); }
        });
        retexCard.addView(pickPng);
        pickPngLabel = CommonUi.dim(this, "No PNG picked.");
        retexCard.addView(pickPngLabel);
        retexCard.addView(CommonUi.dim(this, "Quality preset:"));
        presetSpin = CommonUi.spinner(this, PRESETS);
        retexCard.addView(presetSpin);
        flipCheck = CommonUi.check(this, "Flip vertically (face porting)", false);
        retexCard.addView(flipCheck);
        mipsCheck = CommonUi.check(this, "Generate mipmaps", false);
        retexCard.addView(mipsCheck);
        Button apply = CommonUi.button(this, "Apply retexture");
        apply.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { applyRetexture(); }
        });
        retexCard.addView(apply);
        root.addView(retexCard);

        // face port card
        LinearLayout faceCard = CommonUi.card(this);
        faceCard.addView(CommonUi.label(this, "4. Face port (like the browser tool)"));
        faceCard.addView(CommonUi.dim(this,
                "PNG -> 512x512 white face map. Output: face_<ID>.dds"));
        Button pickFace = CommonUi.buttonGhost(this, "Pick face PNG");
        pickFace.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { pick(PICK_FACE_PNG); }
        });
        faceCard.addView(pickFace);
        LinearLayout fidRow = CommonUi.row(this);
        fidRow.addView(CommonUi.label(this, "Target ID:"));
        faceId = CommonUi.edit(this, "e.g. 1013", "");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(CommonUi.dp(this, 8), 0, 0, 0);
        fidRow.addView(faceId, lp);
        faceCard.addView(fidRow);
        faceFlip = CommonUi.check(this, "Flip vertically", true);
        faceCard.addView(faceFlip);
        Button buildFace = CommonUi.button(this, "Build face map");
        buildFace.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { buildFaceMap(); }
        });
        faceCard.addView(buildFace);
        root.addView(faceCard);

        resultView = CommonUi.dim(this, "");
        root.addView(resultView);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void pick(int code) {
        Intent i = new Intent(this, FilePickerActivity.class);
        startActivityForResult(i, code);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        String path = data.getStringExtra("path");
        if (path == null) return;
        if (req == PICK_SOURCE) {
            loadSource(new File(path));
        } else if (req == PICK_PNG) {
            pngPath = path;
            pickPngLabel.setText("PNG: " + new File(path).getName()
                    + " (" + FileDirs.size(new File(path).length()) + ")");
        } else if (req == PICK_FACE_PNG) {
            buildFaceFrom(path);
        }
    }

    private void loadSource(File f) {
        srcFile = f;
        selectedAsset = null;
        selectedInfo = null;
        scan = null;
        String quick = IffSniffer.classifyQuick(f);
        StringBuilder sb = new StringBuilder();
        sb.append(f.getName()).append(" - ").append(FileDirs.size(f.length()))
          .append("\n").append(quick);
        try {
            scan = IffSniffer.scan(f);
        } catch (IOException e) {
            sb.append("\nScan failed: ").append(e.getMessage());
        }
        if (scan != null && !scan.assets.isEmpty()) {
            sb.append("\n").append(scan.assets.size()).append(" payload(s) found");
        }
        srcInfo.setText(sb.toString());
        rebuildAssetsBox();
    }

    private void rebuildAssetsBox() {
        assetsBox.removeAllViews();
        if (scan == null || scan.assets.isEmpty()) {
            assetsBox.addView(CommonUi.dim(this,
                    "No embedded payloads (or raw DDS selected - the whole file is the texture)."));
            if (srcFile != null && "Raw DDS texture".equals(IffSniffer.classifyQuick(srcFile))) {
                byte[] head = readBytes(srcFile, 0, 128);
                if (head != null) {
                    DdsCodec.Info in = DdsCodec.parse(head, 0);
                    if (in.ok) {
                        selectedInfo = in;
                        assetsBox.addView(CommonUi.label(this,
                                "Whole file: " + in.width + "x" + in.height + " " + in.fmtName()));
                    }
                }
            }
            return;
        }
        int n = 1;
        for (final IffSniffer.Asset a : scan.assets) {
            LinearLayout row = CommonUi.row(this);
            String txt = n + ". " + a.desc + " @ 0x" + Long.toHexString(a.offset)
                    + " (" + FileDirs.size(a.size) + ")";
            TextView tv = CommonUi.label(this, txt);
            row.addView(tv, CommonUi.rowWeighted(tv));
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { selectAsset(a); }
            });
            assetsBox.addView(row);
            n++;
        }
        // auto-select first DDS
        for (IffSniffer.Asset a : scan.assets) {
            if (a.sig == IffSniffer.SIG_DDS) { selectAsset(a); break; }
        }
    }

    private void selectAsset(IffSniffer.Asset a) {
        selectedAsset = a;
        selectedInfo = null;
        byte[] head = readBytes(srcFile, a.offset, 128);
        if (head != null && a.sig == IffSniffer.SIG_DDS) {
            DdsCodec.Info in = DdsCodec.parse(head, 0);
            if (in.ok) selectedInfo = in;
        }
        CommonUi.toast(this, "Selected: " + a.desc);
    }

    private byte[] readBytes(File f, long off, int len) {
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(f, "r");
            if (off + len > raf.length()) len = (int) (raf.length() - off);
            if (len <= 0) return null;
            byte[] b = new byte[len];
            raf.seek(off);
            int n = raf.read(b);
            if (n < len) return null;
            return b;
        } catch (IOException e) {
            return null;
        } finally {
            if (raf != null) try { raf.close(); } catch (IOException ignored) {}
        }
    }

    private int[] targetDims(int srcW, int srcH, int presetIdx) {
        if (presetIdx == 0) return new int[]{srcW, srcH};
        if (presetIdx == 4) return new int[]{Math.max(4, srcW / 2 / 4 * 4),
                                            Math.max(4, srcH / 2 / 4 * 4)};
        int target = presetIdx == 1 ? 1024 : (presetIdx == 2 ? 2048 : 4096);
        int max = Math.max(srcW, srcH);
        if (max <= target) return new int[]{round4(srcW), round4(srcH)};
        float scale = target / (float) max;
        int w = Math.max(4, round4((int) (srcW * scale)));
        int h = Math.max(4, round4((int) (srcH * scale)));
        return new int[]{w, h};
    }

    private int round4(int v) { return Math.max(4, (v / 4) * 4); }

    private void applyRetexture() {
        if (pngPath == null) { CommonUi.toast(this, "Pick a replacement PNG first"); return; }
        if (srcFile == null) { CommonUi.toast(this, "Pick a source IFF / DDS first"); return; }

        Bitmap bmp = BitmapFactory.decodeFile(pngPath);
        if (bmp == null) { CommonUi.toast(this, "Could not decode PNG"); return; }
        int srcW = bmp.getWidth(), srcH = bmp.getHeight();
        if (srcW > 8192 || srcH > 8192) { CommonUi.toast(this, "PNG too large"); return; }

        // base dimensions
        int baseW = srcW, baseH = srcH;
        if (selectedInfo != null) { baseW = selectedInfo.width; baseH = selectedInfo.height; }
        int[] dims = targetDims(baseW, baseH, presetSpin.getSelectedItemPosition());

        int[] px = new int[srcW * srcH];
        bmp.getPixels(px, 0, srcW, 0, 0, srcW, srcH);
        int[] scaled = DdsCodec.resize(px, srcW, srcH, dims[0], dims[1]);
        if (flipCheck.isChecked()) scaled = DdsCodec.flipVertical(scaled, dims[0], dims[1]);

        int fmt = DdsCodec.hasNonOpaqueAlpha(scaled) ? DdsCodec.FMT_DXT5 : DdsCodec.FMT_DXT1;
        byte[] dds = DdsCodec.encode(scaled, dims[0], dims[1], fmt, mipsCheck.isChecked());
        if (dds == null) { CommonUi.toast(this, "Encoding failed"); return; }

        String base = stripExt(srcFile.getName());
        File outDir = dirs.outputDir();
        File outDds = new File(outDir, base + "_" + dims[0] + "x" + dims[1] + ".dds");
        try (FileOutputStream fo = new FileOutputStream(outDds)) {
            fo.write(dds);
        } catch (IOException e) {
            CommonUi.toast(this, "Write failed: " + e.getMessage());
            return;
        }
        String msg = "DDS written: " + outDds.getName() + " (" + FileDirs.size(dds.length) + ", " + (fmt == DdsCodec.FMT_DXT5 ? "DXT5" : "DXT1") + ")";

        if (selectedAsset != null && selectedAsset.size > 0) {
            File outIff = new File(outDir, base + "_retex.iff");
            String err = IffPatch.replaceRegion(srcFile, outIff,
                    selectedAsset.offset, selectedAsset.size, dds);
            if (err == null) {
                msg += "\nPatch container written: " + outIff.getName()
                        + "\nSwap the original in your APK assets folder with this one.";
            } else {
                msg += "\nSame-size swap failed: " + err
                        + "\nRepack the DDS into the IFF with a community tool, or use it as a whole-file replacement.";
            }
        } else if (selectedInfo != null) {
            msg += "\nWhole-file DDS - rename it to the original texture file name in your APK assets.";
        }
        resultView.setText(msg);
        CommonUi.toast(this, "Done - see output folder");
    }

    private void buildFaceFrom(String path) {
        Bitmap bmp = BitmapFactory.decodeFile(path);
        if (bmp == null) { CommonUi.toast(this, "Could not decode PNG"); return; }
        String id = faceId.getText().toString().trim();
        if (id.isEmpty()) { CommonUi.toast(this, "Enter a target ID"); return; }

        // white 512x512 canvas, stretch source into it
        Bitmap canvas = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(canvas);
        cv.drawColor(Color.WHITE);
        android.graphics.Paint paint = new android.graphics.Paint();
        paint.setFilterBitmap(true);
        cv.drawBitmap(bmp, null, new android.graphics.Rect(0, 0, 512, 512), paint);

        int[] px = new int[512 * 512];
        canvas.getPixels(px, 0, 512, 0, 0, 512, 512);
        if (faceFlip.isChecked()) px = DdsCodec.flipVertical(px, 512, 512);
        int fmt = DdsCodec.hasNonOpaqueAlpha(px) ? DdsCodec.FMT_DXT5 : DdsCodec.FMT_DXT1;
        byte[] dds = DdsCodec.encode(px, 512, 512, fmt, false);

        File outDds = new File(dirs.outputDir(), "face_" + id + ".dds");
        try (FileOutputStream fo = new FileOutputStream(outDds)) {
            fo.write(dds);
        } catch (IOException e) {
            CommonUi.toast(this, "Write failed: " + e.getMessage());
            return;
        }
        File preview = new File(dirs.outputDir(), "face_" + id + "_preview.png");
        try (FileOutputStream fo = new FileOutputStream(preview)) {
            canvas.compress(Bitmap.CompressFormat.PNG, 100, fo);
        } catch (IOException ignored) {}
        resultView.setText("Face map written:\n" + outDds.getAbsolutePath()
                + "\n" + preview.getAbsolutePath()
                + "\nRename to the cyberface file name your mod base expects.");
        CommonUi.toast(this, "Face map ready");
    }

    private void buildFaceMap() {
        pick(PICK_FACE_PNG);
    }

    private static String stripExt(String name) {
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name;
    }
}
