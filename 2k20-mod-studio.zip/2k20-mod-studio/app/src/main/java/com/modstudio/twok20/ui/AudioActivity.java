package com.modstudio.twok20.ui;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.modstudio.twok20.core.FileDirs;
import com.modstudio.twok20.core.IffPatch;
import com.modstudio.twok20.core.IffSniffer;

import java.io.File;
import java.io.IOException;

/**
 * Audio Swap: find Ogg / WAV / WEM payloads inside IFF containers,
 * extract + preview them, and byte-swap a replacement of equal or smaller
 * size (zero-padded) - the safe container-preserving method.
 */
public class AudioActivity extends Activity {

    private static final int PICK_SOURCE = 201;
    private static final int PICK_AUDIO = 202;

    private File srcFile;
    private IffSniffer.Result scan;
    private IffSniffer.Asset selected;
    private String replacementPath;
    private MediaPlayer player;

    private TextView srcInfo;
    private LinearLayout list;
    private TextView replLabel;
    private TextView resultView;

    private final FileDirs dirs = new FileDirs();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = CommonUi.scroll(this);
        LinearLayout root = CommonUi.column(this, 12);

        root.addView(CommonUi.title(this, "Audio Swap"));
        root.addView(CommonUi.dim(this,
                "Pick a container file, select an audio payload, extract it, "
                + "then swap in your replacement. Replacement must be the same "
                + "format family and equal or smaller size (it is zero-padded)."));

        LinearLayout srcCard = CommonUi.card(this);
        srcCard.addView(CommonUi.label(this, "1. Source container (IFF)"));
        Button pick = CommonUi.button(this, "Pick container / audio file");
        pick.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivityForResult(
                    new Intent(AudioActivity.this, FilePickerActivity.class), PICK_SOURCE); }
        });
        srcCard.addView(pick);
        srcInfo = CommonUi.dim(this, "No source picked.");
        srcCard.addView(srcInfo);
        root.addView(srcCard);

        LinearLayout listCard = CommonUi.card(this);
        listCard.addView(CommonUi.label(this, "2. Audio payloads"));
        list = CommonUi.column(this);
        listCard.addView(list);
        root.addView(listCard);

        LinearLayout swapCard = CommonUi.card(this);
        swapCard.addView(CommonUi.label(this, "3. Replacement audio"));
        Button pickRepl = CommonUi.buttonGhost(this, "Pick replacement (ogg / wav / wem)");
        pickRepl.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivityForResult(
                    new Intent(AudioActivity.this, FilePickerActivity.class), PICK_AUDIO); }
        });
        swapCard.addView(pickRepl);
        replLabel = CommonUi.dim(this, "No replacement picked.");
        swapCard.addView(replLabel);
        Button swap = CommonUi.button(this, "Swap audio (same-size safe)");
        swap.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { doSwap(); }
        });
        swapCard.addView(swap);
        root.addView(swapCard);

        resultView = CommonUi.dim(this, "");
        root.addView(resultView);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void renderList() {
        list.removeAllViews();
        if (scan == null || scan.assets.isEmpty()) {
            list.addView(CommonUi.dim(this, "No audio payloads found."));
            return;
        }
        int n = 1;
        for (final IffSniffer.Asset a : scan.assets) {
            boolean audio = a.sig == IffSniffer.SIG_OGG || a.sig == IffSniffer.SIG_RIFF
                    || a.sig == IffSniffer.SIG_WEM;
            String txt = n + ". " + a.desc + " @ 0x" + Long.toHexString(a.offset)
                    + " (" + FileDirs.size(a.size) + ")";
            TextView tv = CommonUi.label(this, (audio ? "[AUDIO] " : "[data]  ") + txt);
            tv.setTextColor(audio ? CommonUi.ACCENT : CommonUi.TEXT_DIM);
            LinearLayout row = CommonUi.row(this);
            row.addView(tv, CommonUi.rowWeighted(tv));
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    selected = a;
                    CommonUi.toast(AudioActivity.this, "Selected: " + a.desc);
                }
            });
            list.addView(row);

            LinearLayout btns = CommonUi.row(this);
            Button extract = CommonUi.buttonGhost(this, "Extract");
            extract.setTextSize(12);
            extract.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { extract(a); }
            });
            btns.addView(extract, CommonUi.rowWeighted(extract));
            if (audio) {
                Button play = CommonUi.buttonGhost(this, "Preview");
                play.setTextSize(12);
                play.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) { preview(a); }
                });
                btns.addView(play, CommonUi.rowWeighted(play));
            }
            list.addView(btns);
            n++;
        }
    }

    private void extract(IffSniffer.Asset a) {
        String ext = a.sig == IffSniffer.SIG_OGG ? "ogg"
                : (a.sig == IffSniffer.SIG_RIFF ? "wav"
                : (a.sig == IffSniffer.SIG_WEM ? "wem" : "bin"));
        File out = new File(dirs.extractedDir(),
                stripExt(srcFile.getName()) + "_" + Long.toHexString(a.offset) + "." + ext);
        String err = IffPatch.extractRegion(srcFile, out, a.offset, a.size);
        if (err == null) {
            resultView.setText("Extracted: " + out.getAbsolutePath());
            CommonUi.toast(this, "Saved to ModStudio/Extracted");
        } else {
            CommonUi.toast(this, err);
        }
    }

    private void preview(IffSniffer.Asset a) {
        stopPlayer();
        String ext = a.sig == IffSniffer.SIG_OGG ? "ogg" : "wav";
        File tmp = new File(getCacheDir(), "preview_" + Long.toHexString(a.offset) + "." + ext);
        String err = IffPatch.extractRegion(srcFile, tmp, a.offset, a.size);
        if (err != null) { CommonUi.toast(this, err); return; }
        try {
            player = new MediaPlayer();
            player.setDataSource(tmp.getAbsolutePath());
            player.prepare();
            player.start();
        } catch (Exception e) {
            CommonUi.toast(this, "Preview failed (format may be WEM or unsupported)");
        }
    }

    private void stopPlayer() {
        if (player != null) {
            try { player.stop(); player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    private void doSwap() {
        if (srcFile == null || selected == null) {
            CommonUi.toast(this, "Pick a container and select a payload first");
            return;
        }
        if (replacementPath == null) { CommonUi.toast(this, "Pick a replacement file"); return; }
        File repl = new File(replacementPath);
        byte[] payload = new byte[(int) repl.length()];
        java.io.FileInputStream in = null;
        try {
            in = new java.io.FileInputStream(repl);
            int off = 0;
            while (off < payload.length) {
                int n = in.read(payload, off, payload.length - off);
                if (n < 0) break;
                off += n;
            }
        } catch (IOException e) {
            CommonUi.toast(this, "Read failed: " + e.getMessage());
            return;
        } finally {
            try { if (in != null) in.close(); } catch (IOException ignored) {}
        }
        File out = new File(dirs.outputDir(), stripExt(srcFile.getName()) + "_audioswap.iff");
        String err = IffPatch.replaceRegion(srcFile, out, selected.offset, selected.size, payload);
        if (err == null) {
            resultView.setText("Swapped payload @0x" + Long.toHexString(selected.offset)
                    + " -> " + out.getAbsolutePath());
            CommonUi.toast(this, "Audio swapped");
        } else {
            resultView.setText("Swap failed: " + err);
            CommonUi.toast(this, "Swap failed - see details");
        }
    }

    private static String stripExt(String name) {
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        String path = data.getStringExtra("path");
        if (path == null) return;
        if (req == PICK_SOURCE) {
            srcFile = new File(path);
            String quick = IffSniffer.classifyQuick(srcFile);
            srcInfo.setText(srcFile.getName() + " - " + FileDirs.size(srcFile.length())
                    + "\n" + quick);
            try {
                scan = IffSniffer.scan(srcFile);
            } catch (IOException e) {
                scan = null;
                CommonUi.toast(this, "Scan failed: " + e.getMessage());
            }
            selected = null;
            renderList();
        } else if (req == PICK_AUDIO) {
            replacementPath = path;
            replLabel.setText("Replacement: " + new File(path).getName()
                    + " (" + FileDirs.size(new File(path).length()) + ")");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlayer();
    }
}
