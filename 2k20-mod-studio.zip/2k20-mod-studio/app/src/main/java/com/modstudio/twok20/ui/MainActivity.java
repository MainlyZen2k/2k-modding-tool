package com.modstudio.twok20.ui;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.modstudio.twok20.core.FileDirs;

/**
 * Home screen: storage access + module launcher.
 */
public class MainActivity extends Activity {

    private static final int REQ_LEGACY_WRITE = 41;

    private LinearLayout storageCard;
    private TextView storageStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = CommonUi.scroll(this);
        LinearLayout root = CommonUi.column(this, 16);

        root.addView(header());

        // storage card
        storageCard = CommonUi.card(this);
        storageCard.addView(CommonUi.title(this, "Storage access"));
        storageStatus = CommonUi.dim(this, "");
        storageCard.addView(storageStatus);
        Button grant = CommonUi.button(this, "Grant all-files access");
        grant.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { requestStorage(); }
        });
        storageCard.addView(grant);
        root.addView(storageCard);

        root.addView(moduleCard("Texture Studio",
                "Open IFF / DDS files, inspect embedded textures, retexture with HD / High HD / Ultra HD presets, port faces (flip + 512 white map)."));
        root.addView(moduleCard("Audio Swap",
                "Find Ogg / WAV / WEM payloads inside IFF containers, extract, preview and byte-swap replacement audio."));
        root.addView(moduleCard("Player Editor",
                "Edit the live player structure from the community table: identity, gear, animations, 40+ attributes, tendencies, badges, team code, quarter length and difficulty."));
        root.addView(moduleCard("Patch Lab",
                "Convert GameGuardian tables (76ers, Ball, jersey texture...) into Advanced Features patch profiles and clean GG tables. Built-in catalog included."));
        root.addView(moduleCard("Repack Guide",
                "Step-by-step: extract the APK with ApkEditor, drop IFF mods into assets, apply patch profiles, sign with MT Manager."));
        root.addView(moduleCard("Help & Legal",
                "Workflows, troubleshooting, storage notes and the fair-use / offline-only rules."));

        TextView footer = CommonUi.dim(this,
                "Output folder: /storage/emulated/0/ModStudio\n"
                + "Game package: com.t2ksports.nba2k20and\n"
                + "Personal modding tool - offline use only.");
        footer.setPadding(0, CommonUi.dp(this, 16), 0, CommonUi.dp(this, 16));
        root.addView(footer);

        scroll.addView(root);
        setContentView(scroll);
        refreshStorage();
    }

    private View header() {
        LinearLayout h = CommonUi.row(this);
        LinearLayout txt = CommonUi.column(this);
        TextView name = CommonUi.text(this, "2K20 Mod Studio", 26, CommonUi.ACCENT, true);
        TextView tag = CommonUi.dim(this, "IFF retexture - audio swap - player editor - patch lab");
        txt.addView(name);
        txt.addView(tag);
        h.addView(txt);
        return h;
    }

    private View moduleCard(String title, String desc) {
        LinearLayout card = CommonUi.card(this);
        TextView t = CommonUi.title(this, title);
        TextView d = CommonUi.dim(this, desc);
        card.addView(t);
        card.addView(d);
        card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openModule(title); }
        });
        return card;
    }

    private void openModule(String title) {
        Intent i = null;
        if (title.equals("Texture Studio")) i = new Intent(this, TextureActivity.class);
        else if (title.equals("Audio Swap")) i = new Intent(this, AudioActivity.class);
        else if (title.equals("Player Editor")) i = new Intent(this, PlayerEditorActivity.class);
        else if (title.equals("Patch Lab")) i = new Intent(this, PatchActivity.class);
        else if (title.equals("Repack Guide")) i = new Intent(this, GuideActivity.class);
        else if (title.equals("Help & Legal")) i = new Intent(this, GuideActivity.class);
        if (i != null) startActivity(i);
    }

    private void refreshStorage() {
        boolean ok = hasStorage();
        String out = new FileDirs().outputDir().getAbsolutePath();
        if (ok) {
            storageStatus.setText("Ready. Output: " + out);
            storageStatus.setTextColor(CommonUi.OK);
        } else {
            storageStatus.setText("Not granted yet - the app cannot read or save mod files without it.");
            storageStatus.setTextColor(CommonUi.DANGER);
        }
    }

    private boolean hasStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception e2) {
                    CommonUi.toast(this, "Open Settings > Apps > 2K20 Mod Studio > Files & media");
                }
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    REQ_LEGACY_WRITE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStorage();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        refreshStorage();
    }
}
