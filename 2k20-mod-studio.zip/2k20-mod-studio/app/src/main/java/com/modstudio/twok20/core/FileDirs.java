package com.modstudio.twok20.core;

import java.io.File;

import android.os.Environment;

/**
 * Standard output locations under /storage/emulated/0/ModStudio.
 */
public final class FileDirs {

    public File base() {
        return new File(Environment.getExternalStorageDirectory(), "ModStudio");
    }

    public File outputDir() {
        File f = new File(base(), "Output");
        f.mkdirs();
        return f;
    }

    public File extractedDir() {
        File f = new File(base(), "Extracted");
        f.mkdirs();
        return f;
    }

    public File patchesDir() {
        File f = new File(base(), "patches");
        f.mkdirs();
        return f;
    }

    public static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format("%.1f KB", b / 1024.0);
        return String.format("%.2f MB", b / 1024.0 / 1024.0);
    }
}
