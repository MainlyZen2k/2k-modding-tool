package com.modstudio.twok20.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.modstudio.twok20.core.FileDirs;
import com.modstudio.twok20.core.GgTable;
import com.modstudio.twok20.core.PatchCatalog;
import com.modstudio.twok20.core.PatchProfile;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Player Editor: renders the Ball live player structure from the built-in
 * catalog, grouped into identity / attributes / tendencies / badges / face /
 * team-game, and exports edits as Advanced Features .patch + GG table .txt.
 */
public class PlayerEditorActivity extends Activity {

    private PatchCatalog.Table table;
    private final HashMap<String, String> edits = new HashMap<String, String>();
    private LinearLayout rowsBox;
    private TextView resultView;
    private final FileDirs dirs = new FileDirs();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        table = PatchCatalog.get(this).byId("ball");

        ScrollView scroll = CommonUi.scroll(this);
        LinearLayout root = CommonUi.column(this, 12);

        root.addView(CommonUi.title(this, "Player Editor"));
        LinearLayout warn = CommonUi.card(this);
        TextView wt = CommonUi.text(this,
                "Live-memory offsets for libnba2k20_clean_opt.so (98.0.2). "
                + "Apply while the player you want to edit is loaded. "
                + "Offline modes only - never online.",
                12, CommonUi.DANGER, false);
        warn.addView(wt);
        root.addView(warn);

        if (table == null) {
            root.addView(CommonUi.label(this, "Catalog not found (patch_catalog.json missing)."));
        } else {
            root.addView(CommonUi.dim(this, table.title + " - " + table.entryCount()
                    + " fields from the community table."));

            rowsBox = CommonUi.column(this);
            for (PatchCatalog.Group g : table.groups) {
                LinearLayout card = CommonUi.card(this);
                card.addView(CommonUi.label(this, g.title));
                card.addView(buildGroupRows(g));
                root.addView(card);
            }
        }

        LinearLayout saveCard = CommonUi.card(this);
        Button save = CommonUi.button(this, "Save patch profile + GG table");
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { saveProfiles(); }
        });
        saveCard.addView(save);
        resultView = CommonUi.dim(this, "");
        saveCard.addView(resultView);
        root.addView(saveCard);

        scroll.addView(root);
        setContentView(scroll);
    }

    private View buildGroupRows(PatchCatalog.Group g) {
        LinearLayout box = CommonUi.column(this);
        int i = 0;
        for (final PatchCatalog.Entry e : g.entries) {
            LinearLayout row = CommonUi.row(this);
            LinearLayout txtCol = CommonUi.column(this);
            TextView name = CommonUi.label(this, e.title());
            TextView sub = CommonUi.dim(this, e.subtitle());
            txtCol.addView(name);
            txtCol.addView(sub);
            LinearLayout.LayoutParams txtLp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f);
            txtLp.setMargins(0, CommonUi.dp(this, 4), 0, 0);
            row.addView(txtCol, txtLp);

            final String key = g.id + ":" + i;
            String current = edits.containsKey(key) ? edits.get(key) : e.valueDisplay();
            EditText val = CommonUi.edit(this, e.type, current);
            val.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                    | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                    | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
            LinearLayout.LayoutParams valLp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            valLp.setMargins(CommonUi.dp(this, 8), 0, 0, 0);
            val.addTextChangedListener(new android.text.TextWatcher() {
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
                public void onTextChanged(CharSequence s, int a, int b, int c) {}
                public void afterTextChanged(android.text.Editable s) {
                    edits.put(key, s.toString());
                }
            });
            row.addView(val, valLp);
            box.addView(row);
            i++;
        }
        return box;
    }

    private List<GgTable.Entry> buildEntries(boolean[] outOk) {
        List<GgTable.Entry> out = new ArrayList<GgTable.Entry>();
        boolean ok = true;
        StringBuilder problems = new StringBuilder();
        for (PatchCatalog.Group g : table.groups) {
            int i = 0;
            for (PatchCatalog.Entry ce : g.entries) {
                if (ce.offsetHex == null) { i++; continue; }
                String key = g.id + ":" + i;
                String text = edits.containsKey(key) ? edits.get(key) : ce.valueDisplay();
                GgTable.Entry ge = new GgTable.Entry();
                ge.label = ce.label;
                try {
                    ge.addr = Long.parseLong(ce.addrHex(), 16);
                } catch (Exception ex) {
                    ge.addr = 0;
                }
                ge.type = ce.type;
                ge.size = "byte".equals(ce.type) ? 1 : ("word".equals(ce.type) ? 2 : 4);
                ge.perm = ce.region.equals("lib_code") ? "r-xp"
                        : (ce.region.equals("lib_bss") ? "rw-p" : "rw-p");
                ge.path = ce.libPath();
                ge.offset = safeParse(ce.offsetHex);
                try {
                    if ("float".equals(ce.type)) {
                        ge.floatValue = Float.parseFloat(text.trim());
                    } else {
                        text = text.trim();
                        if (text.startsWith("0x")) {
                            ge.intValue = Long.parseLong(text.substring(2), 16);
                        } else {
                            ge.intValue = Long.parseLong(text, 10);
                        }
                        if ("byte".equals(ce.type) && (ge.intValue < 0 || ge.intValue > 255)) {
                            problems.append("byte out of range: ").append(ce.title()).append('\n');
                            ok = false;
                        }
                        if ("word".equals(ce.type) && (ge.intValue < 0 || ge.intValue > 65535)) {
                            problems.append("word out of range: ").append(ce.title()).append('\n');
                            ok = false;
                        }
                    }
                } catch (NumberFormatException nfe) {
                    problems.append("bad value: ").append(ce.title()).append('\n');
                    ok = false;
                }
                out.add(ge);
                i++;
            }
        }
        outOk[0] = ok;
        if (problems.length() > 0) CommonUi.toast(this, problems.toString().trim());
        return out;
    }

    private Long safeParse(String hex) {
        try { return Long.parseLong(hex, 16); } catch (Exception e) { return null; }
    }

    private void saveProfiles() {
        if (table == null) return;
        boolean[] ok = new boolean[1];
        List<GgTable.Entry> entries = buildEntries(ok);
        File patchOut = new File(dirs.patchesDir(), "player_patches.patch");
        List<PatchProfile.Line> lines = PatchProfile.fromGg(entries);
        boolean p1 = PatchProfile.save(patchOut, lines, "Player editor profile");

        File ggOut = new File(dirs.patchesDir(), "player_table_gg.txt");
        boolean p2 = GgTable.save(ggOut, entries);

        resultView.setText(p1 && p2
                ? "Saved:\n" + patchOut.getAbsolutePath() + "\n" + ggOut.getAbsolutePath()
                : "Save failed - check storage access.");
        CommonUi.toast(this, p1 && p2 ? "Profiles saved" : "Save failed");
    }
}
