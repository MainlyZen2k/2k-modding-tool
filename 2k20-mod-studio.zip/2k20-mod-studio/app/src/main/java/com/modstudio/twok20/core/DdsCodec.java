package com.modstudio.twok20.core;

import android.graphics.Bitmap;
import android.graphics.Color;

/**
 * Pure-Java DDS (DirectDraw Surface) codec: parses DDS headers, decodes
 * DXT1 / DXT3 / DXT5 / A8R8G8B8 / R8G8B8 to ARGB pixels and encodes ARGB
 * pixels back to DDS (auto DXT1 for opaque, DXT5 when alpha present),
 * with optional mipmap chain. No external dependencies.
 *
 * Used by the Texture Studio to retexture payloads found inside NBA 2K20
 * mobile IFF-style containers (the game's DDS textures).
 */
public final class DdsCodec {

    public static final int FMT_UNKNOWN = -1;
    public static final int FMT_DXT1 = 0;
    public static final int FMT_DXT3 = 1;
    public static final int FMT_DXT5 = 2;
    public static final int FMT_RGBA8 = 3;
    public static final int FMT_RGB8 = 4;

    private DdsCodec() {}

    // ---------- little-endian readers ----------

    private static int u8(byte[] d, int i) { return d[i] & 0xFF; }
    private static int u16(byte[] d, int i) {
        return (d[i] & 0xFF) | ((d[i + 1] & 0xFF) << 8);
    }
    private static long u32(byte[] d, int i) {
        return (d[i] & 0xFFL) | ((d[i + 1] & 0xFFL) << 8)
                | ((d[i + 2] & 0xFFL) << 16) | ((d[i + 3] & 0xFFL) << 24);
    }
    private static long u32(byte[] d, long i) {
        int o = (int) i;
        return (d[o] & 0xFFL) | ((d[o + 1] & 0xFFL) << 8)
                | ((d[o + 2] & 0xFFL) << 16) | ((d[o + 3] & 0xFFL) << 24);
    }

    // ---------- header ----------

    public static class Info {
        public int width, height, format = FMT_UNKNOWN, mipCount = 1;
        public long dataOffset = 128;
        public String fourCC = "";
        public boolean ok;

        public String fmtName() {
            switch (format) {
                case FMT_DXT1: return "DXT1";
                case FMT_DXT3: return "DXT3";
                case FMT_DXT5: return "DXT5";
                case FMT_RGBA8: return "A8R8G8B8";
                case FMT_RGB8: return "R8G8B8";
                default: return "unknown" + (fourCC.length() > 0 ? " (" + fourCC + ")" : "");
            }
        }
        public int blockBytes() {
            switch (format) {
                case FMT_DXT1: return 8;
                case FMT_DXT3: case FMT_DXT5: return 16;
                default: return 0;
            }
        }
        public long baseMipSize() {
            if (blockBytes() > 0) {
                long bx = (width + 3) / 4, by = (height + 3) / 4;
                return bx * by * blockBytes();
            }
            if (format == FMT_RGBA8) return (long) width * height * 4;
            if (format == FMT_RGB8) return (long) width * height * 3;
            return 0;
        }
    }

    /** Parse a DDS header from the given buffer (starting at buf[0] = 'D'). */
    public static Info parse(byte[] d, int off) {
        Info info = new Info();
        if (d == null || d.length - off < 128) return info;
        if (!(d[off] == 'D' && d[off + 1] == 'D' && d[off + 2] == 'S' && d[off + 3] == ' ')) {
            return info;
        }
        info.width = (int) u32(d, off + 16);
        info.height = (int) u32(d, off + 12);
        info.mipCount = Math.max(1, (int) u32(d, off + 28));
        long pfFlags = u32(d, off + 80);
        StringBuilder cc = new StringBuilder();
        for (int i = 0; i < 4; i++) cc.append((char) u8(d, off + 84 + i));
        info.fourCC = cc.toString().trim();
        long bitCount = u32(d, off + 88);

        if (info.width <= 0 || info.height <= 0
                || info.width > 8192 || info.height > 8192) return info;

        if ("DXT1".equals(info.fourCC)) info.format = FMT_DXT1;
        else if ("DXT2".equals(info.fourCC) || "DXT3".equals(info.fourCC)) info.format = FMT_DXT3;
        else if ("DXT4".equals(info.fourCC) || "DXT5".equals(info.fourCC)) info.format = FMT_DXT5;
        else if ("DX10".equals(info.fourCC)) info.format = FMT_UNKNOWN;
        else if ((pfFlags & 0x40L) != 0) { // DDPF_RGB
            if (bitCount == 32) info.format = FMT_RGBA8;
            else if (bitCount == 24) info.format = FMT_RGB8;
        }
        info.ok = info.format != FMT_UNKNOWN;
        return info;
    }

    /** Human description of a DDS byte slice, or null if not a DDS. */
    public static String describe(byte[] slice) {
        Info in = parse(slice, 0);
        if (!in.ok) return null;
        return in.width + "x" + in.height + " " + in.fmtName()
                + (in.mipCount > 1 ? " mips=" + in.mipCount : "");
    }

    // ---------- decode ----------

    /** Decode the base (largest) mip into a Bitmap, or null. */
    public static Bitmap decode(byte[] d) {
        Info in = parse(d, 0);
        if (!in.ok) return null;
        int[] argb = decodeMip(d, in);
        if (argb == null) return null;
        return Bitmap.createBitmap(argb, in.width, in.height, Bitmap.Config.ARGB_8888);
    }

    static int[] decodeMip(byte[] d, Info in) {
        int w = in.width, h = in.height;
        long need = in.baseMipSize();
        if (in.dataOffset + need > d.length) return null;
        int[] out = new int[w * h];
        try {
            switch (in.format) {
                case FMT_DXT1: decodeDXT1(d, in, out); break;
                case FMT_DXT3: decodeDXT3(d, in, out); break;
                case FMT_DXT5: decodeDXT5(d, in, out); break;
                case FMT_RGBA8: decodeRGBA8(d, in, out); break;
                case FMT_RGB8: decodeRGB8(d, in, out); break;
                default: return null;
            }
        } catch (Exception e) {
            return null;
        }
        return out;
    }

    private static int to888(int c565) {
        int r = ((c565 >> 11) & 31) * 255 / 31;
        int g = ((c565 >> 5) & 63) * 255 / 63;
        int b = (c565 & 31) * 255 / 31;
        return (r << 16) | (g << 8) | b;
    }

    private static void decodeBlockColors(byte[] d, int bo, int[] pal, boolean allowThree) {
        int c0 = u16(d, bo), c1 = u16(d, bo + 2);
        pal[0] = 0xFF000000 | to888(c0);
        pal[1] = 0xFF000000 | to888(c1);
        if (c0 > c1 || !allowThree) { // 4-color mode (DXT3/DXT5 always 4-color)
            int r0 = (pal[0] >> 16) & 255, g0 = (pal[0] >> 8) & 255, b0 = pal[0] & 255;
            int r1 = (pal[1] >> 16) & 255, g1 = (pal[1] >> 8) & 255, b1 = pal[1] & 255;
            int r2 = (2 * r0 + r1 + 1) / 3, g2 = (2 * g0 + g1 + 1) / 3, b2 = (2 * b0 + b1 + 1) / 3;
            int r3 = (r0 + 2 * r1 + 1) / 3, g3 = (g0 + 2 * g1 + 1) / 3, b3 = (b0 + 2 * b1 + 1) / 3;
            pal[2] = 0xFF000000 | (r2 << 16) | (g2 << 8) | b2;
            pal[3] = 0xFF000000 | (r3 << 16) | (g3 << 8) | b3;
        } else { // 3-color + transparent (DXT1 only)
            int r0 = (pal[0] >> 16) & 255, g0 = (pal[0] >> 8) & 255, b0 = pal[0] & 255;
            int r1 = (pal[1] >> 16) & 255, g1 = (pal[1] >> 8) & 255, b1 = pal[1] & 255;
            int r2 = (r0 + r1) / 2, g2 = (g0 + g1) / 2, b2 = (b0 + b1) / 2;
            pal[2] = 0xFF000000 | (r2 << 16) | (g2 << 8) | b2;
            pal[3] = 0x00000000;
        }
    }

    private static void decodeDXT1(byte[] d, Info in, int[] out) {
        int w = in.width, h = in.height;
        int bx = (w + 3) / 4, by = (h + 3) / 4;
        int[] pal = new int[4];
        for (int byi = 0; byi < by; byi++) {
            for (int bxi = 0; bxi < bx; bxi++) {
                int bo = (int) in.dataOffset + (byi * bx + bxi) * 8;
                decodeBlockColors(d, bo, pal, true);
                long bits = u32(d, bo + 4);
                for (int y = 0; y < 4; y++) {
                    int py = byi * 4 + y;
                    if (py >= h) break;
                    for (int x = 0; x < 4; x++) {
                        int px = bxi * 4 + x;
                        if (px >= w) break;
                        int idx = (int) ((bits >>> (2 * (y * 4 + x))) & 3);
                        out[py * w + px] = pal[idx];
                    }
                }
            }
        }
    }

    private static void decodeDXT3(byte[] d, Info in, int[] out) {
        int w = in.width, h = in.height;
        int bx = (w + 3) / 4, by = (h + 3) / 4;
        int[] pal = new int[4];
        for (int byi = 0; byi < by; byi++) {
            for (int bxi = 0; bxi < bx; bxi++) {
                int bo = (int) in.dataOffset + (byi * bx + bxi) * 16;
                decodeBlockColors(d, bo + 8, pal, false);
                for (int y = 0; y < 4; y++) {
                    int py = byi * 4 + y;
                    if (py >= h) break;
                    int row = u16(d, bo + y * 2);
                    long cbits = u32(d, bo + 12);
                    for (int x = 0; x < 4; x++) {
                        int px = bxi * 4 + x;
                        if (px >= w) break;
                        int idx = (int) ((cbits >>> (2 * (y * 4 + x))) & 3);
                        int a = ((row >>> (4 * x)) & 15) * 17;
                        out[py * w + px] = (a << 24) | (pal[idx] & 0xFFFFFF);
                    }
                }
            }
        }
    }

    private static long bits2(byte[] d, int bo) { return u32(d, bo); }

    private static void decodeDXT5(byte[] d, Info in, int[] out) {
        int w = in.width, h = in.height;
        int bx = (w + 3) / 4, by = (h + 3) / 4;
        int[] pal = new int[4];
        int[] apal = new int[8];
        for (int byi = 0; byi < by; byi++) {
            for (int bxi = 0; bxi < bx; bxi++) {
                int bo = (int) in.dataOffset + (byi * bx + bxi) * 16;
                int a0 = u8(d, bo), a1 = u8(d, bo + 1);
                long abits = 0;
                for (int i = 0; i < 6; i++) abits |= (d[bo + 2 + i] & 0xFFL) << (8 * i);
                if (a0 > a1) {
                    apal[0] = a0; apal[1] = a1;
                    for (int i = 2; i < 8; i++) {
                        int n = i - 2; // (6,5,4,3,2,1) weights
                        apal[i] = ((6 - n) * a0 + n * a1 + 3) / 7;
                    }
                } else {
                    apal[0] = a0; apal[1] = a1;
                    apal[2] = (4 * a0 + a1 + 2) / 5;
                    apal[3] = (3 * a0 + 2 * a1 + 2) / 5;
                    apal[4] = (2 * a0 + 3 * a1 + 2) / 5;
                    apal[5] = (a0 + 4 * a1 + 2) / 5;
                    apal[6] = 0; apal[7] = 255;
                }
                decodeBlockColors(d, bo + 8, pal, false);
                long cbits = u32(d, bo + 12);
                for (int y = 0; y < 4; y++) {
                    int py = byi * 4 + y;
                    if (py >= h) break;
                    for (int x = 0; x < 4; x++) {
                        int px = bxi * 4 + x;
                        if (px >= w) break;
                        int i = y * 4 + x;
                        int ai = (int) ((abits >>> (3 * i)) & 7);
                        int ci = (int) ((cbits >>> (2 * i)) & 3);
                        out[py * w + px] = (apal[ai] << 24) | (pal[ci] & 0xFFFFFF);
                    }
                }
            }
        }
    }

    private static void decodeRGBA8(byte[] d, Info in, int[] out) {
        int o = (int) in.dataOffset;
        for (int i = 0; i < out.length; i++) {
            int b = u8(d, o + 4 * i), g = u8(d, o + 4 * i + 1);
            int r = u8(d, o + 4 * i + 2), a = u8(d, o + 4 * i + 3);
            out[i] = (a << 24) | (r << 16) | (g << 8) | b;
        }
    }

    private static void decodeRGB8(byte[] d, Info in, int[] out) {
        int w = in.width, h = in.height;
        long pitch = u32(d, 20);
        if (pitch <= 0) pitch = w * 3;
        int o = (int) in.dataOffset;
        for (int y = 0; y < h; y++) {
            int row = o + (int) pitch * y;
            for (int x = 0; x < w; x++) {
                int p = row + 3 * x;
                int b = u8(d, p), g = u8(d, p + 1), r = u8(d, p + 2);
                out[y * w + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
    }

    // ---------- encode ----------

    private static boolean hasAlpha(int[] argb) {
        for (int p : argb) if ((p >>> 24) < 255) return true;
        return false;
    }

    private static int q5(int v) { return Math.min(31, (v * 31 + 127) / 255); }
    private static int q6(int v) { return Math.min(63, (v * 63 + 127) / 255); }
    private static int to565(int r, int g, int b) {
        return (q5(r) << 11) | (q6(g) << 5) | q5(b);
    }

    private static int nearest(int r, int g, int b, int[] pal, int n) {
        int best = 0; long bd = Long.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            int p = pal[i];
            int dr = r - ((p >> 16) & 255), dg = g - ((p >> 8) & 255), db = b - (p & 255);
            long dist = dr * dr * 2L + dg * dg * 4L + db * db;
            if (dist < bd) { bd = dist; best = i; }
        }
        return best;
    }

    /** Encode one 4x4 color block (edge pixels replicated). allowPunch = DXT1 punch-through. */
    private static long encodeColorBlock(int[] argb, int w, int h, int bx0, int by0,
                                         boolean allowPunch, byte[] out, int bo) {
        int[] px = new int[16];
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 4; x++) {
                int sx = Math.min(bx0 * 4 + x, w - 1);
                int sy = Math.min(by0 * 4 + y, h - 1);
                px[y * 4 + x] = argb[sy * w + sx];
            }
        }
        // luminance extremes as endpoints
        int lo = 0, hi = 0; float ll = Float.MAX_VALUE, lh = -1;
        for (int i = 0; i < 16; i++) {
            int p = px[i];
            float lum = 0.299f * ((p >> 16) & 255) + 0.587f * ((p >> 8) & 255) + 0.114f * (p & 255);
            if (lum < ll) { ll = lum; lo = i; }
            if (lum > lh) { lh = lum; hi = i; }
        }
        int pLo = px[lo], pHi = px[hi];
        int c0 = to565((pHi >> 16) & 255, (pHi >> 8) & 255, pHi & 255);
        int c1 = to565((pLo >> 16) & 255, (pLo >> 8) & 255, pLo & 255);
        if (c0 < c1) { int t = c0; c0 = c1; c1 = t; }
        boolean fourColor = (c0 > c1) || !allowPunch;
        int[] pal = new int[4];
        pal[0] = 0xFF000000 | to888(c0);
        pal[1] = 0xFF000000 | to888(c1);
        int r0 = (pal[0] >> 16) & 255, g0 = (pal[0] >> 8) & 255, b0 = pal[0] & 255;
        int r1 = (pal[1] >> 16) & 255, g1 = (pal[1] >> 8) & 255, b1 = pal[1] & 255;
        if (fourColor) {
            pal[2] = 0xFF000000 | (((2 * r0 + r1 + 1) / 3) << 16) | (((2 * g0 + g1 + 1) / 3) << 8) | ((2 * b0 + b1 + 1) / 3);
            pal[3] = 0xFF000000 | (((r0 + 2 * r1 + 1) / 3) << 16) | (((g0 + 2 * g1 + 1) / 3) << 8) | ((b0 + 2 * b1 + 1) / 3);
        } else {
            pal[2] = 0xFF000000 | (((r0 + r1) / 2) << 16) | (((g0 + g1) / 2) << 8) | ((b0 + b1) / 2);
            pal[3] = 0x00000000;
        }
        long bits = 0;
        int n = fourColor ? 4 : 3;
        for (int i = 0; i < 16; i++) {
            int p = px[i];
            int idx = nearest((p >> 16) & 255, (p >> 8) & 255, p & 255, pal, n);
            if (allowPunch && !fourColor && (p >>> 24) < 128) idx = 3; // punch-through transparency
            bits |= (long) idx << (2 * i);
        }
        out[bo] = (byte) c0; out[bo + 1] = (byte) (c0 >> 8);
        out[bo + 2] = (byte) c1; out[bo + 3] = (byte) (c1 >> 8);
        for (int i = 0; i < 4; i++) out[bo + 4 + i] = (byte) ((bits >>> (8 * i)) & 0xFF);
        return bits;
    }

    /** Encode one DXT5 alpha block, writes 8 bytes at out[bo..bo+7]. */
    private static void encodeAlphaBlock(int[] argb, int w, int h, int bx0, int by0,
                                         byte[] out, int bo) {
        int[] al = new int[16];
        int amin = 255, amax = 0;
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 4; x++) {
                int sx = Math.min(bx0 * 4 + x, w - 1);
                int sy = Math.min(by0 * 4 + y, h - 1);
                int a = argb[sy * w + sx] >>> 24;
                al[y * 4 + x] = a;
                if (a < amin) amin = a;
                if (a > amax) amax = a;
            }
        }
        int a0, a1;
        if (amin == amax) { a0 = a1 = amin; }
        else { a0 = amax; a1 = amin; }
        int[] apal = new int[8];
        apal[0] = a0; apal[1] = a1;
        if (a0 > a1) {
            for (int i = 2; i < 8; i++) {
                int n = i - 2;
                apal[i] = ((6 - n) * a0 + n * a1 + 3) / 7;
            }
        } else {
            apal[2] = (4 * a0 + a1 + 2) / 5;
            apal[3] = (3 * a0 + 2 * a1 + 2) / 5;
            apal[4] = (2 * a0 + 3 * a1 + 2) / 5;
            apal[5] = (a0 + 4 * a1 + 2) / 5;
            apal[6] = 0; apal[7] = 255;
        }
        long bits = 0;
        for (int i = 0; i < 16; i++) {
            int idx = nearest(al[i], al[i], al[i], apal, 8);
            bits |= (long) idx << (3 * i);
        }
        out[bo] = (byte) a0; out[bo + 1] = (byte) a1;
        for (int i = 0; i < 6; i++) out[bo + 2 + i] = (byte) ((bits >>> (8 * i)) & 0xFF);
    }

    private static void encodeBlocks(int[] argb, int w, int h, int fmt, byte[] data, int dataOff) {
        int bx = (w + 3) / 4, by = (h + 3) / 4;
        for (int byi = 0; byi < by; byi++) {
            for (int bxi = 0; bxi < bx; bxi++) {
                int idx = byi * bx + bxi;
                if (fmt == FMT_DXT1) {
                    encodeColorBlock(argb, w, h, bxi, byi, true, data, dataOff + idx * 8);
                } else { // DXT5 - color part never uses punch-through
                    encodeAlphaBlock(argb, w, h, bxi, byi, data, dataOff + idx * 16);
                    encodeColorBlock(argb, w, h, bxi, byi, false, data, dataOff + idx * 16 + 8);
                }
            }
        }
    }

    private static int[] boxDownsample(int[] src, int w, int h) {
        int nw = Math.max(1, w / 2), nh = Math.max(1, h / 2);
        int[] dst = new int[nw * nh];
        for (int y = 0; y < nh; y++) {
            for (int x = 0; x < nw; x++) {
                int x2 = Math.min(x * 2 + 1, w - 1), y2 = Math.min(y * 2 + 1, h - 1);
                int p00 = src[y * 2 * w + x * 2], p01 = src[y * 2 * w + x2];
                int p10 = src[y2 * w + x * 2], p11 = src[y2 * w + x2];
                int a = ((p00 >>> 24) + (p01 >>> 24) + (p10 >>> 24) + (p11 >>> 24)) / 4;
                int r = (((p00 >> 16) & 255) + ((p01 >> 16) & 255) + ((p10 >> 16) & 255) + ((p11 >> 16) & 255)) / 4;
                int g = (((p00 >> 8) & 255) + ((p01 >> 8) & 255) + ((p10 >> 8) & 255) + ((p11 >> 8) & 255)) / 4;
                int b = ((p00 & 255) + (p01 & 255) + (p10 & 255) + (p11 & 255)) / 4;
                dst[y * nw + x] = (a << 24) | (r << 16) | (g << 8) | b;
            }
        }
        return dst;
    }

    /**
     * Encode ARGB pixels to a full DDS file.
     * fmt: FMT_DXT1 / FMT_DXT5 (or FMT_RGBA8 for uncompressed).
     * mips: generate full mip chain (power-of-two sizes recommended).
     */
    public static byte[] encode(int[] argb, int w, int h, int fmt, boolean mips) {
        if (w <= 0 || h <= 0 || argb.length < w * h) return null;
        if (fmt != FMT_DXT1 && fmt != FMT_DXT5 && fmt != FMT_RGBA8) return null;

        java.util.ArrayList<byte[]> mipData = new java.util.ArrayList<byte[]>();
        java.util.ArrayList<int[]> dims = new java.util.ArrayList<int[]>();
        int cw = w, ch = h;
        int[] cur = argb;
        int count = 0;
        int maxMips = mips ? 32 : 1;
        while (true) {
            int blockBytes = (fmt == FMT_DXT1) ? 8 : (fmt == FMT_DXT5 ? 16 : 0);
            int mipSize;
            byte[] data;
            if (blockBytes > 0) {
                mipSize = ((cw + 3) / 4) * ((ch + 3) / 4) * blockBytes;
                data = new byte[mipSize];
                encodeBlocks(cur, cw, ch, fmt, data, 0);
            } else {
                mipSize = cw * ch * 4;
                data = new byte[mipSize];
                for (int i = 0; i < cw * ch; i++) {
                    int p = cur[i];
                    data[4 * i] = (byte) (p & 255);
                    data[4 * i + 1] = (byte) ((p >> 8) & 255);
                    data[4 * i + 2] = (byte) ((p >> 16) & 255);
                    data[4 * i + 3] = (byte) ((p >> 24) & 255);
                }
            }
            mipData.add(data);
            dims.add(new int[]{cw, ch});
            count++;
            if (count >= maxMips || (cw == 1 && ch == 1)) break;
            cur = boxDownsample(cur, cw, ch);
            cw = Math.max(1, cw / 2);
            ch = Math.max(1, ch / 2);
        }

        int headerSize = 128;
        long total = headerSize;
        for (byte[] m : mipData) total += m.length;
        byte[] dds = new byte[(int) total];

        // magic 'DDS '
        dds[0] = 'D'; dds[1] = 'D'; dds[2] = 'S'; dds[3] = ' ';
        put32(dds, 4, 124);
        int flags = 0x1 | 0x2 | 0x4 | 0x1000 | 0x20000; // CAPS|HEIGHT|WIDTH|PIXELFORMAT|MIPMAPCOUNT
        int blockBytes = (fmt == FMT_DXT1) ? 8 : (fmt == FMT_DXT5 ? 16 : 0);
        if (blockBytes > 0) {
            flags |= 0x80000; // LINEARSIZE
            put32(dds, 20, ((w + 3) / 4) * ((h + 3) / 4) * blockBytes);
        } else {
            flags |= 0x8; // PITCH
            put32(dds, 20, w * 4);
        }
        put32(dds, 8, flags);
        put32(dds, 12, h);
        put32(dds, 16, w);
        put32(dds, 24, 0); // depth
        put32(dds, 28, count); // mips

        // pixel format at 76
        put32(dds, 76, 32);
        int pfFlags;
        if (blockBytes > 0) {
            pfFlags = 0x4; // DDPF_FOURCC
            dds[84] = (byte) 'D';
            dds[85] = 'X'; dds[86] = 'T';
            dds[87] = (fmt == FMT_DXT1) ? (byte) '1' : (byte) '5';
        } else {
            pfFlags = 0x41; // RGB | ALPHAPIXELS
            put32(dds, 88, 32);
            put32(dds, 92, 0x00FF0000); // R
            put32(dds, 96, 0x0000FF00); // G
            put32(dds, 100, 0x000000FF); // B
            put32(dds, 104, 0xFF000000); // A
        }
        put32(dds, 80, pfFlags);
        put32(dds, 108, 0x1000 | (mips ? 0x400000 | 0x40000 : 0)); // caps

        int o = headerSize;
        for (byte[] m : mipData) {
            System.arraycopy(m, 0, dds, o, m.length);
            o += m.length;
        }
        return dds;
    }

    /** Convenience: encode a Bitmap (auto picks DXT5 if any pixel is translucent). */
    public static byte[] encode(Bitmap bmp, boolean mips) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        int fmt = hasAlpha(px) ? FMT_DXT5 : FMT_DXT1;
        return encode(px, w, h, fmt, mips);
    }

    public static byte[] encodeExplicit(int[] px, int w, int h, int fmt, boolean mips) {
        return encode(px, w, h, fmt, mips);
    }

    public static boolean hasNonOpaqueAlpha(int[] px) { return hasAlpha(px); }

    // ---------- resize ----------

    /** Simple bilinear resize of ARGB pixels. */
    public static int[] resize(int[] src, int sw, int sh, int dw, int dh) {
        if (sw == dw && sh == dh) return src;
        int[] dst = new int[dw * dh];
        for (int y = 0; y < dh; y++) {
            float fy = (dh == 1) ? 0f : (y * (sh - 1)) / (float) (dh - 1);
            int y0 = (int) fy, y1 = Math.min(y0 + 1, sh - 1);
            float wy = fy - y0;
            for (int x = 0; x < dw; x++) {
                float fx = (dw == 1) ? 0f : (x * (sw - 1)) / (float) (dw - 1);
                int x0 = (int) fx, x1 = Math.min(x0 + 1, sw - 1);
                float wx = fx - x0;
                int p00 = src[y0 * sw + x0], p01 = src[y0 * sw + x1];
                int p10 = src[y1 * sw + x0], p11 = src[y1 * sw + x1];
                int a = bil(p00 >>> 24, p01 >>> 24, p10 >>> 24, p11 >>> 24, wx, wy);
                int r = bil((p00 >> 16) & 255, (p01 >> 16) & 255, (p10 >> 16) & 255, (p11 >> 16) & 255, wx, wy);
                int g = bil((p00 >> 8) & 255, (p01 >> 8) & 255, (p10 >> 8) & 255, (p11 >> 8) & 255, wx, wy);
                int b = bil(p00 & 255, p01 & 255, p10 & 255, p11 & 255, wx, wy);
                dst[y * dw + x] = (a << 24) | (r << 16) | (g << 8) | b;
            }
        }
        return dst;
    }

    private static int bil(int c00, int c01, int c10, int c11, float wx, float wy) {
        float top = c00 + (c01 - c00) * wx;
        float bot = c10 + (c11 - c10) * wx;
        return Math.round(top + (bot - top) * wy);
    }

    /** Flip pixels vertically (used when porting faces from 2K14 etc.). */
    public static int[] flipVertical(int[] src, int w, int h) {
        int[] dst = new int[src.length];
        for (int y = 0; y < h; y++) {
            System.arraycopy(src, y * w, dst, (h - 1 - y) * w, w);
        }
        return dst;
    }

    private static void put32(byte[] d, int i, long v) {
        d[i] = (byte) v; d[i + 1] = (byte) (v >> 8);
        d[i + 2] = (byte) (v >> 16); d[i + 3] = (byte) (v >> 24);
    }
}
