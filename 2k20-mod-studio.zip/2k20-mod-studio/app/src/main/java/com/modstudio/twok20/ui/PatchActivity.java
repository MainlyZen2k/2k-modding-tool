package com.modstudio.twok20.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.modstudio.twok20.core.FileDirs;
import com.modstudio.twok20.core.GgTable;
import com.modstudio.twok20.core.PatchCatalog;
import com.modstudio.twok20.core.PatchProfile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Patch Lab: browse the built-in catalog, convert GG tables into
 * Advanced Features .patch profiles and back, with stability warnings.
 */
public class PatchActivity extends Activity {

    private static final int PICK_GG = 301;

    private FileDirs dirs = new FileDirs();
    private Spinner tableSpin;
    private LinearLayout catalogBox;
    private TextView importInfo;
    private List<GgTable.Entry> imported;
    private String importedName = "imported";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = CommonUi.scroll(this);
        LinearLayout root = CommonUi.column(this, 12);

        root.addView(CommonUi.title(this, "Patch Lab"));

        // built-in catalog
        LinearLayout catCard = CommonUi.card(this);
        catCard.addView(CommonUi.label(this, "Built-in catalog (from the community tables)"));
        PatchCatalog.Catalog cat = PatchCatalog.get(this);
        String[] names = new String[cat.tables.size()];
        for (int i = 0; i < cat.tables.size(); i++) {
            PatchCatalog.Table t = cat.tables.get(i);
            names[i] = t.title + " (" + t.entryCount() + ")";
        }
        tableSpin = CommonUi.spinner(this, names);
        catCard.addView(tableSpin);
        Button show = CommonUi.buttonGhost(this, "Show table");
        show.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showCatalog(); }
        });
        catCard.addView(show);
        LinearLayout expRow = CommonUi.row(this);
        Button expPatch = CommonUi.buttonGhost(this, "Export .patch");
        expPatch.setTextSize(12);
        expPatch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exportCatalog(true); }
        });
        Button expGg = CommonUi.buttonGhost(this, "Export GG .txt");
        expGg.setTextSize(12);
        expGg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exportCatalog(false); }
        });
        expRow.addView(expPatch, CommonUi.rowWeighted(expPatch));
        expRow.addView(expGg, CommonUi.rowWeighted(expGg));
        catCard.addView(expRow);
        catalogBox = CommonUi.column(this);
        catCard.addView(catalogBox);
        root.addView(catCard);

        // import card
        LinearLayout impCard = CommonUi.card(this);
        impCard.addView(CommonUi.label(this, "Import a GameGuardian table (.txt)"));
        Button pick = CommonUi.button(this, "Pick GG table file");
        pick.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { startActivityForResult(
                    new Intent(PatchActivity.this, FilePickerActivity.class), PICK_GG); }
        });
        impCard.addView(pick);
        importInfo = CommonUi.dim(this, "Nothing imported yet.");
        impCard.addView(importInfo);
        LinearLayout impRow = CommonUi.row(this);
        Button impPatch = CommonUi.buttonGhost(this, "Convert to .patch");
        impPatch.setTextSize(12);
        impPatch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exportImported(true); }
        });
        Button impGg = CommonUi.buttonGhost(this, "Save clean GG .txt");
        impGg.setTextSize(12);
        impGg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exportImported(false); }
        });
        impRow.addView(impPatch, CommonUi.rowWeighted(impPatch));
        impRow.addView(impGg, CommonUi.rowWeighted(impGg));
        impCard.addView(impRow);
        root.addView(impCard);

        // formats info
        LinearLayout info = CommonUi.card(this);
        info.addView(CommonUi.label(this, "Patch formats"));
        TextView fmt = CommonUi.text(this,
                "Advanced Features .patch (one line per write):\n"
                + "  name|0xoffset|type|value\n"
                + "  example: Player shadow|0x2162cdc|float|4.0\n\n"
                + "GameGuardian table (.txt):\n"
                + "  Var #name|addr|type|hexvalue|0|0|0|0|perm|map path|offset\n\n"
                + "The injected loader of a modded APK reads profiles at launch and writes "
                + "them into libnba2k20_clean_opt.so memory (mprotect + memcpy). A reference "
                + "modloader.cpp ships with this project in docs/native/.",
                12, CommonUi.TEXT, false);
        fmt.setTypeface(Typeface.MONOSPACE);
        info.addView(fmt);
        root.addView(info);

        scroll.addView(root);
        setContentView(scroll);
    }

    private PatchCatalog.Table currentTable() {
        int idx = tableSpin.getSelectedItemPosition();
        PatchCatalog.Catalog cat = PatchCatalog.get(this);
        if (idx < 0 || idx >= cat.tables.size()) return null;
        return cat.tables.get(idx);
    }

    private void showCatalog() {
        PatchCatalog.Table t = currentTable();
        if (t == null) return;
        catalogBox.removeAllViews();
        catalogBox.addView(CommonUi.dim(this, t.note == null || t.note.isEmpty() ? "" : t.note));
        for (PatchCatalog.Group g : t.groups) {
            TextView h = CommonUi.label(this, g.title + " (" + g.entries.size() + ")");
            h.setTextColor(CommonUi.ACCENT);
            catalogBox.addView(h);
            int shown = 0;
            for (PatchCatalog.Entry e : g.entries) {
                if (shown++ >= 8) {
                    catalogBox.addView(CommonUi.dim(this, "... " + (g.entries.size() - 8)
                            + " more in this group"));
                    break;
                }
                String warn = GgTable.stabilityNote(convert(e));
                TextView row = CommonUi.dim(this, "- " + e.title()
                        + "  " + e.type + "@0x" + e.offsetHex + " = " + e.valueDisplay()
                        + (warn.isEmpty() ? "" : "  [" + warn + "]"));
                catalogBox.addView(row);
            }
        }
    }

    private GgTable.Entry convert(PatchCatalog.Entry ce) {
        GgTable.Entry ge = new GgTable.Entry();
        ge.label = ce.label;
        try { ge.addr = Long.parseLong(ce.addrHex(), 16); } catch (Exception e) { ge.addr = 0; }
        ge.type = ce.type;
        ge.size = "byte".equals(ce.type) ? 1 : ("word".equals(ce.type) ? 2 : 4);
        ge.perm = ce.perm.isEmpty() ? "rw-p" : ce.perm;
        ge.path = ce.libPath();
        try { ge.offset = ce.offsetHex == null ? null : Long.parseLong(ce.offsetHex, 16); }
        catch (Exception e) { ge.offset = null; }
        if (ce.isFloat) ge.floatValue = ce.floatValue; else ge.intValue = ce.intValue;
        return ge;
    }

    private List<GgTable.Entry> catalogAsGg() {
        PatchCatalog.Table t = currentTable();
        List<GgTable.Entry> out = new ArrayList<GgTable.Entry>();
        if (t == null) return out;
        for (PatchCatalog.Group g : t.groups)
            for (PatchCatalog.Entry e : g.entries) out.add(convert(e));
        return out;
    }

    private void exportCatalog(boolean asPatch) {
        PatchCatalog.Table t = currentTable();
        if (t == null) return;
        List<GgTable.Entry> entries = catalogAsGg();
        File out;
        if (asPatch) {
            out = new File(dirs.patchesDir(), t.id + ".patch");
            PatchProfile.save(out, PatchProfile.fromGg(entries), t.title);
        } else {
            out = new File(dirs.patchesDir(), t.id + "_gg.txt");
            GgTable.save(out, entries);
        }
        CommonUi.toast(this, "Saved " + out.getName());
        importInfo.setText("Last export: " + out.getAbsolutePath());
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        String path = data.getStringExtra("path");
        if (path == null) return;
        if (req == PICK_GG) {
            try {
                imported = GgTable.parse(new File(path));
                importedName = stripExt(new File(path).getName());
                Map<String, Integer> regions = new HashMap<String, Integer>();
                int heap = 0;
                for (GgTable.Entry e : imported) {
                    regions.put(e.region, regions.getOrDefault(e.region, 0) + 1);
                    if ("heap".equals(e.region)) heap++;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(importedName).append(": ").append(imported.size()).append(" entries\n");
                sb.append(regions.toString());
                if (heap > 0) sb.append("\nWARNING: ").append(heap)
                        .append(" heap entries are device/session specific.");
                importInfo.setText(sb.toString());
            } catch (IOException e) {
                CommonUi.toast(this, "Parse failed: " + e.getMessage());
            }
        }
    }

    private void exportImported(boolean asPatch) {
        if (imported == null || imported.isEmpty()) {
            CommonUi.toast(this, "Import a GG table first");
            return;
        }
        File out;
        if (asPatch) {
            out = new File(dirs.patchesDir(), importedName + ".patch");
            PatchProfile.save(out, PatchProfile.fromGg(imported), importedName);
        } else {
            out = new File(dirs.patchesDir(), importedName + "_clean.txt");
            GgTable.save(out, imported);
        }
        CommonUi.toast(this, "Saved " + out.getName());
        importInfo.append("\nExport: " + out.getAbsolutePath());
    }

    private static String stripExt(String name) {
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name;
    }
}
