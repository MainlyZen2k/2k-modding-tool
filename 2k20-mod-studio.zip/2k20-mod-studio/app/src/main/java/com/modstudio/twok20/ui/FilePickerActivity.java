package com.modstudio.twok20.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Minimal dark file picker rooted at the shared storage root.
 * Returns the picked absolute path via setResult (extra "path").
 */
public class FilePickerActivity extends Activity {

    private LinearLayout root;
    private TextView pathView;
    private ListView list;
    private File current = new File(Environment.getExternalStorageDirectory().getAbsolutePath());
    private ArrayAdapter<String> adapter;
    private final List<File> shown = new ArrayList<File>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout page = CommonUi.column(this, 8);

        LinearLayout bar = CommonUi.row(this);
        Button up = CommonUi.buttonGhost(this, "Up");
        up.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                File p = current.getParentFile();
                if (p != null && p.canRead()) navigate(p);
            }
        });
        bar.addView(up, CommonUi.rowWeighted(up));
        Button here = CommonUi.button(this, "Use this folder");
        here.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finishOk(current.getAbsolutePath()); }
        });
        bar.addView(here, CommonUi.rowWeighted(here));
        page.addView(bar);

        pathView = CommonUi.dim(this, "");
        page.addView(pathView);

        LinearLayout quick = CommonUi.row(this);
        addQuick(quick, "Download");
        addQuick(quick, "DCIM");
        addQuick(quick, "Documents");
        addQuick(quick, "ModStudio");
        page.addView(quick);

        list = new ListView(this);
        list.setBackgroundColor(CommonUi.BG);
        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                TextView tv = (TextView) v;
                tv.setTextColor(CommonUi.TEXT);
                tv.setTextSize(14);
                return v;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                File f = shown.get(position);
                if (f.isDirectory()) navigate(f);
                else finishOk(f.getAbsolutePath());
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                File f = shown.get(position);
                if (f.isFile()) {
                    String info = "Size: " + f.length() + " bytes\n\nFirst bytes:\n"
                            + IffPatchProxy.hexPreview(f, 64);
                    new android.app.AlertDialog.Builder(FilePickerActivity.this)
                            .setTitle(f.getName())
                            .setMessage(info)
                            .setPositiveButton("Pick", new android.content.DialogInterface.OnClickListener() {
                                public void onClick(android.content.DialogInterface d, int w) {
                                    finishOk(f.getAbsolutePath());
                                }
                            })
                            .setNegativeButton("Close", null)
                            .show();
                }
                return true;
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        page.addView(list, lp);

        setContentView(page);
        navigate(current);
    }

    private void addQuick(LinearLayout bar, String name) {
        Button b = CommonUi.buttonGhost(this, name);
        b.setTextSize(12);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                File f = new File(Environment.getExternalStorageDirectory(), name);
                if (f.exists()) navigate(f); else CommonUi.toast(FilePickerActivity.this, name + " not found");
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(3, 0, 3, 0);
        bar.addView(b, lp);
    }

    private void navigate(File dir) {
        File[] files = dir.listFiles();
        current = dir;
        pathView.setText(dir.getAbsolutePath());
        shown.clear();
        if (files != null) {
            Collections.addAll(shown, files);
            Collections.sort(shown, (a, b) -> {
                if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                return a.getName().compareToIgnoreCase(b.getName());
            });
        }
        adapter.clear();
        for (File f : shown) {
            adapter.add((f.isDirectory() ? "[DIR] " : "      ") + f.getName()
                    + (f.isFile() ? "  (" + f.length() + " B)" : ""));
        }
        adapter.notifyDataSetChanged();
        setTitle(dir.getName().isEmpty() ? "Storage" : dir.getName());
    }

    private void finishOk(String path) {
        Intent data = new Intent();
        data.putExtra("path", path);
        setResult(RESULT_OK, data);
        finish();
    }

    /** Static bridge so the picker does not import the core package directly. */
    private static final class IffPatchProxy {
        static String hexPreview(File f, int n) { return com.modstudio.twok20.core.IffPatch.hexPreview(f, n); }
    }
}
