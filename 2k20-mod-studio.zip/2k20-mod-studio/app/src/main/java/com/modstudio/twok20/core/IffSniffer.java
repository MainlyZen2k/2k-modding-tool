package com.modstudio.twok20.core;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Content-sniffing engine for NBA 2K20 mobile asset files.
 *
 * 2K ships game content inside ".iff" style containers. Community modding
 * works on them without a full container spec by scanning for embedded
 * payload signatures (DDS textures, Ogg/WAV audio, Wwise WEM banks, PNGs).
 * This scanner finds those payloads, estimates their sizes and lets the
 * patcher do safe same-size replacement - the workflow the modding scene
 * relies on.
 */
public final class IffSniffer {

    private IffSniffer() {}

    public static final int SIG_DDS = 0;
    public static final int SIG_OGG = 1;
    public static final int SIG_RIFF = 2;
    public static final int SIG_PNG = 3;
    public static final int SIG_WEM = 4; // Wwise (BKHD)
    public static final int SIG_IFFS = 5;
    public static final int SIG_FORM = 6;

    public static class Asset {
        public long offset;
        public long size;          // best-effort estimate, clamped to next signature / EOF
        public int sig;
        public String desc;

        public String sigName() {
            switch (sig) {
                case SIG_DDS: return "DDS texture";
                case SIG_OGG: return "Ogg audio";
                case SIG_RIFF: return "RIFF (WAV)";
                case SIG_PNG: return "PNG image";
                case SIG_WEM: return "Wwise WEM audio";
                case SIG_IFFS: return "IFFS container";
                case SIG_FORM: return "FORM container";
                default: return "unknown";
            }
        }
    }

    public static class Result {
        public long fileSize;
        public List<Asset> assets = new ArrayList<Asset>();
        public String containerHeader = "";  // first 4 bytes as ascii (printable)
        public String containerGuess = "unknown / raw data";

        public boolean hasTextures() {
            for (Asset a : assets) if (a.sig == SIG_DDS || a.sig == SIG_PNG) return true;
            return false;
        }
        public boolean hasAudio() {
            for (Asset a : assets)
                if (a.sig == SIG_OGG || a.sig == SIG_RIFF || a.sig == SIG_WEM) return true;
            return false;
        }
    }

    private static final byte[][] SIGS = {
            {'D', 'D', 'S', ' '},          // DDS
            {'O', 'g', 'g', 'S'},          // Ogg
            {'R', 'I', 'F', 'F'},          // RIFF
            {(byte) 0x89, 'P', 'N', 'G'},  // PNG
            {'B', 'K', 'H', 'D'},          // Wwise
            {'I', 'F', 'F', 'S'},          // 2K IFF family
            {'F', 'O', 'R', 'M'},          // EA/Amiga IFF
    };

    public static String magicAt(RandomAccessFile raf, long off) throws IOException {
        raf.seek(off);
        byte[] m = new byte[4];
        int n = raf.read(m);
        if (n < 4) return "";
        StringBuilder sb = new StringBuilder();
        for (byte b : m) sb.append((b >= 32 && b < 127) ? (char) b : '.');
        return sb.toString();
    }

    /** Scan a file for embedded payload signatures. */
    public static Result scan(File f) throws IOException {
        Result res = new Result();
        res.fileSize = f.length();
        RandomAccessFile raf = new RandomAccessFile(f, "r");
        try {
            res.containerHeader = magicAt(raf, 0);
            List<long[]> hits = new ArrayList<long[]>(); // [offset, sigIndex]
            long bufSize = 1 << 20;
            byte[] buf = new byte[(int) bufSize];
            long pos = 0;
            int overlap = 3;
            while (pos < res.fileSize) {
                long start = Math.max(0, pos - overlap);
                raf.seek(start);
                int toRead = (int) Math.min(bufSize, res.fileSize - start);
                int n = raf.read(buf, 0, toRead);
                if (n <= 0) break;
                for (int i = 0; i <= n - 4; i++) {
                    for (int s = 0; s < SIGS.length; s++) {
                        byte[] sg = SIGS[s];
                        if (buf[i] == sg[0] && buf[i + 1] == sg[1]
                                && buf[i + 2] == sg[2] && buf[i + 3] == sg[3]) {
                            hits.add(new long[]{start + i, s});
                        }
                    }
                }
                pos = start + n;
            }
            Collections.sort(hits, new Comparator<long[]>() {
                public int compare(long[] a, long[] b) { return Long.compare(a[0], b[0]); }
            });

            long coveredUntil = 0;
            for (int hi = 0; hi < hits.size(); hi++) {
                long off = hits.get(hi)[0];
                int sig = (int) hits.get(hi)[1];
                if (off < coveredUntil) continue;
                long nextSig = (hi + 1 < hits.size()) ? hits.get(hi + 1)[0] : res.fileSize;

                Asset a = new Asset();
                a.offset = off;
                a.sig = sig;
                long est;
                try {
                    switch (sig) {
                        case SIG_DDS: est = estimateDds(raf, off); break;
                        case SIG_OGG: est = estimateOgg(raf, off); break;
                        case SIG_RIFF: est = estimateRiff(raf, off); break;
                        case SIG_PNG: est = estimatePng(raf, off); break;
                        case SIG_WEM: est = estimateWem(raf, off); break;
                        default: est = 0;
                    }
                } catch (Exception e) {
                    est = 0;
                }
                if (est <= 0) est = Math.max(0, res.fileSize - off);
                long end = Math.min(off + est, nextSig);
                if (end <= off) end = Math.min(off + est, res.fileSize);
                a.size = Math.max(0, end - off);
                a.desc = describeAsset(raf, a);
                if (sig == SIG_IFFS || sig == SIG_FORM) {
                    res.containerGuess = (sig == SIG_IFFS)
                            ? "IFFS-style container (2K IFF family)"
                            : "FORM container (EA/Amiga IFF style)";
                    coveredUntil = off + 4; // just note the header; keep scanning inside
                } else {
                    res.assets.add(a);
                    coveredUntil = off + a.size;
                }
            }

            if (res.containerGuess.startsWith("unknown")) {
                if (res.hasTextures() && res.hasAudio()) {
                    res.containerGuess = "mixed container (textures + audio payloads)";
                } else if (res.hasTextures()) {
                    res.containerGuess = "texture container (DDS payloads found)";
                } else if (res.hasAudio()) {
                    res.containerGuess = "audio container (Ogg/WAV/WEM payloads found)";
                }
            }
        } finally {
            try { raf.close(); } catch (IOException ignored) {}
        }
        return res;
    }

    private static String describeAsset(RandomAccessFile raf, Asset a) {
        try {
            if (a.sig == SIG_DDS) {
                byte[] head = new byte[128];
                raf.seek(a.offset);
                int n = raf.read(head);
                if (n == 128) {
                    DdsCodec.Info in = DdsCodec.parse(head, 0);
                    if (in.ok) return in.width + "x" + in.height + " " + in.fmtName()
                            + (in.mipCount > 1 ? " mips=" + in.mipCount : "");
                }
            } else if (a.sig == SIG_RIFF) {
                raf.seek(a.offset + 8);
                byte[] t = new byte[4];
                if (raf.read(t) == 4 && new String(t, "US-ASCII").equals("WAVE")) return "WAV PCM";
                return "RIFF container";
            } else if (a.sig == SIG_OGG) {
                return "Ogg Vorbis stream";
            } else if (a.sig == SIG_WEM) {
                return "Wwise encoded media";
            }
        } catch (Exception ignored) {}
        return a.sigName();
    }

    private static long estimateDds(RandomAccessFile raf, long off) throws IOException {
        byte[] head = new byte[128];
        raf.seek(off);
        if (raf.read(head) < 128) return 0;
        DdsCodec.Info in = DdsCodec.parse(head, 0);
        if (!in.ok) return 0;
        long total = 0;
        long w = in.width, h = in.height;
        int mips = Math.max(1, in.mipCount);
        for (int i = 0; i < mips && w > 0 && h > 0; i++) {
            long bx = (w + 3) / 4, by = (h + 3) / 4;
            total += in.blockBytes() > 0 ? bx * by * in.blockBytes()
                    : (in.format == DdsCodec.FMT_RGBA8 ? w * h * 4 : w * h * 3);
            w = Math.max(1, w / 2); h = Math.max(1, h / 2);
        }
        return total;
    }

    private static long estimateOgg(RandomAccessFile raf, long off) throws IOException {
        // walk Ogg pages
        long size = 0;
        long pos = off;
        int pages = 0;
        while (pages < 4096) {
            raf.seek(pos);
            byte[] h = new byte[27];
            if (raf.read(h) < 27) break;
            if (!(h[0] == 'O' && h[1] == 'g' && h[2] == 'g' && h[3] == 'S')) break;
            int segs = h[26] & 0xFF;
            byte[] segTable = new byte[segs];
            if (raf.read(segTable) < segs) break;
            int body = 0;
            for (byte s : segTable) body += s & 0xFF;
            long pageSize = 27 + segs + body;
            size += pageSize;
            pos += pageSize;
            pages++;
            if (pos >= raf.length()) break;
        }
        return size > 0 ? size : 0;
    }

    private static long estimateRiff(RandomAccessFile raf, long off) throws IOException {
        raf.seek(off + 4);
        byte[] b = new byte[4];
        if (raf.read(b) < 4) return 0;
        long sz = (b[0] & 0xFFL) | ((b[1] & 0xFFL) << 8) | ((b[2] & 0xFFL) << 16)
                | ((b[3] & 0xFFL) << 24);
        if (sz <= 0) return 0;
        return 8 + sz;
    }

    private static long estimatePng(RandomAccessFile raf, long off) throws IOException {
        long pos = off + 8;
        for (int i = 0; i < 4096; i++) {
            raf.seek(pos);
            byte[] h = new byte[8];
            if (raf.read(h) < 8) break;
            long len = ((h[0] & 0xFFL) << 24) | ((h[1] & 0xFFL) << 16)
                    | ((h[2] & 0xFFL) << 8) | (h[3] & 0xFFL);
            if (len < 0 || len > 64 * 1024 * 1024) break;
            pos += 12 + len;
            if (h[4] == 'I' && h[5] == 'E' && h[6] == 'N' && h[7] == 'D') {
                return pos - off;
            }
            if (pos >= raf.length()) break;
        }
        return 0;
    }

    private static long estimateWem(RandomAccessFile raf, long off) throws IOException {
        // WEM = sequence of RIFF-like chunks: fourcc + u32 size + data
        long pos = off;
        long lastGood = 0;
        for (int i = 0; i < 64; i++) {
            raf.seek(pos);
            byte[] h = new byte[8];
            if (raf.read(h) < 8) break;
            boolean printable = true;
            for (int k = 0; k < 4; k++) {
                if (h[k] < 32 || h[k] > 126) printable = false;
            }
            if (!printable) break;
            long len = (h[4] & 0xFFL) | ((h[5] & 0xFFL) << 8) | ((h[6] & 0xFFL) << 16)
                    | ((h[7] & 0xFFL) << 24);
            if (len < 0 || len > 512 * 1024 * 1024) break;
            pos += 8 + len;
            lastGood = pos;
            if (pos >= raf.length()) break;
        }
        return lastGood;
    }

    /** Quick overall classification of a picked file. */
    public static String classifyQuick(File f) {
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(f, "r");
            String m = magicAt(raf, 0);
            if (m.startsWith("DDS ")) return "Raw DDS texture";
            if (m.startsWith("IFFS")) return "IFFS-style container (2K IFF family)";
            if (m.startsWith("FORM")) return "FORM container (IFF family)";
            if (m.startsWith("OggS")) return "Ogg audio";
            if (m.startsWith("RIFF")) return "RIFF (WAV or similar)";
            if (m.startsWith("\u0089PNG")) return "PNG image";
            if (m.startsWith("BKHD")) return "Wwise WEM audio";
            return "Data file (signature: " + (m.isEmpty() ? "empty" : m) + ")";
        } catch (Exception e) {
            return "Unreadable";
        } finally {
            if (raf != null) try { raf.close(); } catch (IOException ignored) {}
        }
    }
}
