package com.modstudio.twok20.ui;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * In-app help: workflows, repack checklist, troubleshooting, legal notes.
 */
public class GuideActivity extends Activity {

    private static final String[][] SECTIONS = {
        {"Quick start",
            "1) Open Settings and grant the app all-files access.\n"
            + "2) Extract your game APK with ApkEditor or MT Manager (extract to a folder, not install).\n"
            + "3) Work on copies: copy the .iff you want to mod into Download or ModStudio.\n"
            + "4) Texture Studio / Audio Swap / Patch Lab process files in /storage/emulated/0/ModStudio/Output.\n"
            + "5) Put the patched .iff back into the APK assets folder, rebuild and sign, install."},
        {"Storage & Android 11+ notes",
            "Shared storage (Download, DCIM, ModStudio) works with the All-files-access grant.\n\n"
            + "Android/data and Android/obb are blocked on Android 11+ even with all-files access. "
            + "This is why the modding community uses MT Manager or Shizuku for the data folder. "
            + "Practical flow used by modders: copy files between Android/data and Download using MT Manager "
            + "(or a Shizuku-powered file manager), then edit with this app."},
        {"Texture workflow",
            "Texture Studio -> pick the .iff you copied out of the APK.\n"
            + "- The scanner lists embedded DDS payloads with dimensions and format.\n"
            + "- Tap a payload to select it, then extract it as PNG to use as a template.\n"
            + "- Import your replacement PNG and choose a preset:\n"
            + "    Original size = safest, guaranteed same-size swap.\n"
            + "    HD 1024 / High HD 2048 / Ultra HD 4096 = upscale along the longest side (kept on a multiple of 4).\n"
            + "- Flip vertically is needed when porting older face textures (they load bottom-up).\n"
            + "- Mipmaps improve far-view quality; disable them if the game ignores them anyway.\n"
            + "- Apply writes both the .dds and, when the payload fits, a *_retex.iff container with the payload swapped in."},
        {"Face port workflow",
            "This mirrors the browser '2k14 CF port to 2k20 mobile' tool:\n"
            + "1) Get the face as a PNG (or extract the DDS from a 2K14 .iff and convert it to PNG first).\n"
            + "2) Texture Studio -> Face port -> pick the PNG, enter the target cyberface ID, keep Flip vertically on.\n"
            + "3) You get a 512x512 white face map: face_<ID>.dds plus a PNG preview.\n"
            + "4) Rename it to the file name your mod base expects (check what your modded APK ships in its face folder) "
            + "or inject it into the matching payload with a community IFF tool."},
        {"Audio workflow",
            "Audio Swap -> pick the container. The scanner lists Ogg / WAV / Wwise payloads.\n"
            + "- Extract payloads you want to replace and listen to the preview to identify them.\n"
            + "- Prepare your replacement in the SAME family (ogg for ogg, wav for wav, wem for wem) "
            + "and keep it equal or smaller in bytes.\n"
            + "- Swap writes a *_audioswap.iff with the payload zero-padded in place."},
        {"Player editor workflow",
            "The built-in catalog comes straight from the community Ball table (98.0.2 lib offsets).\n"
            + "- Identity, gear and animations are byte/word fields; attributes and tendencies are 0-255; "
            + "badges are bitmask bytes; salaries are dwords.\n"
            + "- These offsets point into the LIVE player structure in memory, so they are applied as patch "
            + "profiles while the player you want to edit is loaded (roster screen, career screen or via an "
            + "Advanced Features loader).\n"
            + "- Save writes /sdcard/ModStudio/patches/player_patches.patch plus a GameGuardian-compatible .txt."},
        {"Patch Lab & Advanced Features",
            "Modded APKs (like the A2K MOBILE builds) ship GG tables inside assets/Advanced Features and use an "
            + "injected loader lib (libpine-style) to apply them at launch - that is how they replace GameGuardian.\n"
            + "- Patch Lab converts your .txt GG tables into clean .patch profiles (name|0xoffset|type|value).\n"
            + "- It also converts profiles back into GG tables for sharing.\n"
            + "- Heap entries ([anon:libc_malloc]) are device/session specific and marked unstable; "
            + "lib_bss entries depend on the exact lib build (98.0.2); code (r-xp) entries patch instructions - "
            + "keep backups and stay offline."},
        {"Repack checklist",
            "1) Back up the original APK (or copy it to PC).\n"
            + "2) ApkEditor: decode (extract) the APK - do not use quick reinstall.\n"
            + "3) assets/ holds the mod folders (courts, jerseys, logos, font, Advanced Features...).\n"
            + "4) Replace the .iff you modded with the *_retex.iff / swapped output - keep the SAME file name.\n"
            + "5) Optional: place your .patch profiles into the Advanced Features folder if your loader reads them.\n"
            + "6) ApkEditor: build APK.\n"
            + "7) MT Manager: sign the APK (key: keep one consistent personal key so updates install).\n"
            + "8) Uninstall the original app first if the signature differs.\n"
            + "9) Install, go offline (airplane mode), launch and test.\n"
            + "10) Crash on load? Restore the original .iff you replaced - a size mismatch in a critical texture is the usual cause."},
        {"Troubleshooting",
            "- Access denied on Android/data: use MT Manager / Shizuku to copy files out first.\n"
            + "- Patched IFF crashes the game: you replaced a payload with a bigger/smaller DDS than expected - "
            + "retry with Original size preset.\n"
            + "- Ultra HD makes the game stutter or crash on load: your device ran out of texture memory - drop to High HD.\n"
            + "- GG table import shows 0 entries: the file needs the Var #|addr|type|value format on each line.\n"
            + "- Patches do not stick: the lib build differs - offsets are for the 98.0.2 lib."},
        {"Fair use & legal",
            "This tool is for personal, offline customization of a game YOU own.\n"
            + "- Never distribute repacked APKs or game assets - 2K content is copyrighted and redistribution is illegal.\n"
            + "- Never use mods, memory edits or patch profiles in online modes: it ruins matches for others and gets accounts banned.\n"
            + "- Community tables and offsets are shared by modders for personal use - credit authors (Xiao Ke, Xue Wangjia, "
            + "Sebastian2k, DAN2K and the rest of the scene) when you share derived profiles.\n"
            + "- No warranty: always back up your APK and saves before patching."},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = CommonUi.scroll(this);
        LinearLayout root = CommonUi.column(this, 12);

        root.addView(CommonUi.title(this, "Help, workflows & fair use"));
        for (String[] sec : SECTIONS) {
            LinearLayout card = CommonUi.card(this);
            TextView h = CommonUi.label(this, sec[0]);
            h.setTextColor(CommonUi.ACCENT);
            h.setTypeface(Typeface.DEFAULT_BOLD);
            card.addView(h);
            TextView body = CommonUi.text(this, sec[1], 13, CommonUi.TEXT, false);
            body.setLineSpacing(0, 1.15f);
            card.addView(body);
            root.addView(card);
        }
        TextView ver = CommonUi.dim(this, "2K20 Mod Studio v1.0 - built from the community workflow.");
        ver.setPadding(0, CommonUi.dp(this, 12), 0, CommonUi.dp(this, 12));
        root.addView(ver);

        scroll.addView(root);
        setContentView(scroll);
    }
}
