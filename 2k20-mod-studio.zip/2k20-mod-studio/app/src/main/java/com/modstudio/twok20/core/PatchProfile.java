package com.modstudio.twok20.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * "Advanced Features" patch profile - the format the modding community uses
 * to bake GameGuardian-style memory patches into a modded APK (the injected
 * loader lib reads one text file per feature and applies the writes at
 * runtime after the game lib is mapped).
 *
 * Our documented, tool-friendly layout (one entry per line):
 *   name|0xOFFSET|type|value
 * type: byte | word | dword | float
 * value: decimal (or 0x hex for integer types), float as decimal.
 *
 * ModStudio exports both this format and clean GameGuardian tables.
 */
public final class PatchProfile {

    public static class Line {
        public String name;
        public long offset;
        public String type; // byte|word|dword|float
        public long intValue;
        public float floatValue;

        public String valueText() {
            return "float".equals(type) ? Float.toString(floatValue) : Long.toString(intValue);
        }
        public void parseValue(String s) {
            s = s.trim();
            if ("float".equals(type)) {
                floatValue = Float.parseFloat(s);
            } else {
                if (s.startsWith("0x") || s.startsWith("0X")) {
                    intValue = Long.parseLong(s.substring(2), 16);
                } else {
                    intValue = Long.parseLong(s, 10);
                }
            }
        }
        public String render() {
            StringBuilder sb = new StringBuilder();
            sb.append(name).append("|0x").append(Long.toHexString(offset))
              .append('|').append(type).append('|').append(valueText());
            return sb.toString();
        }
    }

    private static final Charset UTF8 = Charset.forName("UTF-8");
    public static final String HEADER = "# 2K20 Mod Studio patch profile v1";

    public static List<Line> parse(File f) throws IOException {
        List<Line> out = new ArrayList<Line>();
        BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), UTF8));
        try {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] p = line.split("\\|");
                if (p.length < 4) continue;
                Line l = new Line();
                l.name = p[0];
                String offHex = p[1].replace("0x", "").replace("0X", "");
                try {
                    l.offset = Long.parseLong(offHex, 16);
                } catch (NumberFormatException nfe) {
                    continue;
                }
                l.type = p[2].trim().toLowerCase();
                if (!"byte".equals(l.type) && !"word".equals(l.type)
                        && !"dword".equals(l.type) && !"float".equals(l.type)) continue;
                try {
                    l.parseValue(p[3]);
                } catch (NumberFormatException nfe) {
                    continue;
                }
                out.add(l);
            }
        } finally {
            try { r.close(); } catch (IOException ignored) {}
        }
        return out;
    }

    public static boolean save(File out, List<Line> lines, String title) {
        try {
            OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(out), UTF8);
            w.write(HEADER + "\n");
            w.write("# " + title + "\n");
            w.write("# name|0xoffset|type|value\n");
            for (Line l : lines) w.write(l.render() + "\n");
            w.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /** Convert GameGuardian entries (lib-based, with offsets) into a profile. */
    public static List<Line> fromGg(List<GgTable.Entry> entries) {
        List<Line> out = new ArrayList<Line>();
        for (GgTable.Entry e : entries) {
            if (e.offset == null) continue;
            if (!("lib_bss".equals(e.region) || "lib_data".equals(e.region)
                    || "lib_code".equals(e.region))) continue;
            Line l = new Line();
            String nm = e.label;
            if (nm.startsWith("Var #")) nm = nm.substring(5);
            l.name = nm.isEmpty() ? ("patch_" + Long.toHexString(e.offset)) : nm;
            l.offset = e.offset;
            l.type = e.type;
            if ("float".equals(e.type)) l.floatValue = e.floatValue;
            else l.intValue = e.intValue;
            out.add(l);
        }
        return out;
    }
}
