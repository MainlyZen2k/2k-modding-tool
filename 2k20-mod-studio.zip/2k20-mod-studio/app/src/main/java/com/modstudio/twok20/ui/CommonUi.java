package com.modstudio.twok20.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Small dark-theme widget factory so every screen looks consistent without
 * dozens of layout XML files (also keeps the project buildable on-device).
 */
public final class CommonUi {

    public static final int BG = 0xFF141414;
    public static final int PANEL = 0xFF1E1E1E;
    public static final int PANEL2 = 0xFF262626;
    public static final int ACCENT = 0xFFF28C28;
    public static final int ACCENT_DIM = 0xFFB26113;
    public static final int TEXT = 0xFFEDEDED;
    public static final int TEXT_DIM = 0xFF9E9E9E;
    public static final int DANGER = 0xFFE0533D;
    public static final int OK = 0xFF57A65A;

    private CommonUi() {}

    public static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static ScrollView scroll(Context c) {
        ScrollView sv = new ScrollView(c);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        return sv;
    }

    public static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout column(Context c, int padDp) {
        LinearLayout l = column(c);
        int p = dp(c, padDp);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = column(c);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(c, 10), 0, 0);
        l.setLayoutParams(lp);
        l.setBackgroundResource(android.R.drawable.dialog_frame); // replaced below
        l.setBackground(new android.graphics.drawable.GradientDrawable() {
            {
                setColor(PANEL);
                setCornerRadius(dp(c, 10));
                setStroke(dp(c, 1), 0xFF2E2E2E);
            }
        });
        int p = dp(c, 12);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView title(Context c, String s) { return text(c, s, 18, TEXT, true); }
    public static TextView label(Context c, String s) { return text(c, s, 14, TEXT, false); }
    public static TextView dim(Context c, String s) { return text(c, s, 12, TEXT_DIM, false); }

    public static TextView chip(Context c, String s, int bg, int fg) {
        TextView t = text(c, s, 11, fg, false);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(bg);
        gd.setCornerRadius(dp(c, 6));
        t.setBackground(gd);
        t.setPadding(dp(c, 6), dp(c, 2), dp(c, 6), dp(c, 2));
        return t;
    }

    public static Button button(Context c, String s) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(ACCENT_DIM);
        gd.setCornerRadius(dp(c, 8));
        b.setBackground(gd);
        b.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        return b;
    }

    public static Button buttonGhost(Context c, String s) {
        Button b = button(c, s);
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(PANEL2);
        gd.setCornerRadius(dp(c, 8));
        gd.setStroke(dp(c, 1), ACCENT_DIM);
        b.setBackground(gd);
        return b;
    }

    public static EditText edit(Context c, String hint, String value) {
        EditText e = new EditText(c);
        e.setHint(hint);
        if (value != null) e.setText(value);
        e.setTextColor(TEXT);
        e.setHintTextColor(0xFF666666);
        e.setTextSize(14);
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(0xFF111111);
        gd.setCornerRadius(dp(c, 6));
        gd.setStroke(dp(c, 1), 0xFF3A3A3A);
        e.setBackground(gd);
        e.setPadding(dp(c, 10), dp(c, 8), dp(c, 10), dp(c, 8));
        return e;
    }

    public static CheckBox check(Context c, String s, boolean checked) {
        CheckBox ch = new CheckBox(c);
        ch.setText(s);
        ch.setTextColor(TEXT);
        ch.setTextSize(13);
        ch.setChecked(checked);
        return ch;
    }

    public static Spinner spinner(Context c, String[] items) {
        Spinner s = new Spinner(c);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(c,
                android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(ad);
        return s;
    }

    public static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_LONG).show();
    }

    /** Horizontal params helper: weight 1 in a row. */
    public static LinearLayout.LayoutParams rowWeighted(View v) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }
}
