package com.modstudio.twok20.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * Safe byte-level patching of containers:
 *  - replaceRegion(): write new payload into an existing region, padding with
 *    zeros when the payload is smaller (the community "same-size swap" that
 *    keeps IFF containers valid).
 *  - extractRegion(): copy a region out as its own file.
 * All patches are applied to a temp copy and atomically renamed.
 */
public final class IffPatch {

    private IffPatch() {}

    public static final int MAX_PAD = 64 * 1024 * 1024;

    /**
     * Replace the region [offset, offset+regionSize) in file {@code target}
     * with {@code payload}. If payload is smaller, the remaining bytes are
     * zero-filled. Returns an error string, or null on success.
     * The patched copy is written to {@code output}.
     */
    public static String replaceRegion(File source, File output, long offset,
                                       long regionSize, byte[] payload) {
        if (offset < 0 || regionSize <= 0) return "Bad region";
        if (payload == null || payload.length == 0) return "Empty payload";
        if (payload.length > regionSize) {
            return "Payload (" + payload.length + " B) is larger than the region ("
                    + regionSize + " B). Use a smaller image or export as standalone DDS.";
        }
        if (regionSize - payload.length > MAX_PAD) return "Padding too large - region looks wrong";
        FileInputStream in = null;
        FileOutputStream out = null;
        File tmp = new File(output.getParentFile(), output.getName() + ".tmp");
        try {
            in = new FileInputStream(source);
            out = new FileOutputStream(tmp);
            long pos = 0;
            byte[] buf = new byte[65536];
            // copy up to offset
            while (pos < offset) {
                int n = in.read(buf, 0, (int) Math.min(buf.length, offset - pos));
                if (n < 0) return "File shorter than region offset";
                out.write(buf, 0, n);
                pos += n;
            }
            // skip original region
            long skip = regionSize;
            while (skip > 0) {
                int n = in.read(buf, 0, (int) Math.min(buf.length, skip));
                if (n < 0) return "File shorter than region end";
                skip -= n;
                pos += n;
            }
            // write payload
            out.write(payload);
            // zero pad
            long pad = regionSize - payload.length;
            if (pad > 0) {
                byte[] zeros = new byte[4096];
                while (pad > 0) {
                    int n = (int) Math.min(zeros.length, pad);
                    out.write(zeros, 0, n);
                    pad -= n;
                }
            }
            // copy remainder
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();
        } catch (IOException e) {
            return "I/O error: " + e.getMessage();
        } finally {
            try { if (in != null) in.close(); } catch (IOException ignored) {}
            try { if (out != null) out.close(); } catch (IOException ignored) {}
        }
        if (!tmp.renameTo(output)) {
            tmp.delete();
            return "Could not finalize output file";
        }
        return null;
    }

    /** Extract a region to its own file. Returns error string or null. */
    public static String extractRegion(File source, File output, long offset, long size) {
        RandomAccessFile raf = null;
        FileOutputStream out = null;
        try {
            raf = new RandomAccessFile(source, "r");
            if (offset + size > raf.length()) return "Region exceeds file size";
            raf.seek(offset);
            out = new FileOutputStream(output);
            byte[] buf = new byte[65536];
            long left = size;
            while (left > 0) {
                int n = raf.read(buf, 0, (int) Math.min(buf.length, left));
                if (n < 0) break;
                out.write(buf, 0, n);
                left -= n;
            }
            out.flush();
            return null;
        } catch (IOException e) {
            return "I/O error: " + e.getMessage();
        } finally {
            try { if (raf != null) raf.close(); } catch (IOException ignored) {}
            try { if (out != null) out.close(); } catch (IOException ignored) {}
        }
    }

    /** Read the first bytes of a file as a hex preview (for the file picker). */
    public static String hexPreview(File f, int count) {
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(f, "r");
            byte[] b = new byte[count];
            int n = raf.read(b);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < n; i++) {
                sb.append(String.format("%02X", b[i]));
                if ((i % 16) == 15) sb.append('\n');
                else if ((i % 2) == 1) sb.append(' ');
            }
            return sb.toString();
        } catch (Exception e) {
            return "(unreadable)";
        } finally {
            if (raf != null) try { try { raf.close(); } catch (IOException ignored) {} } catch (Exception ignored) {}
        }
    }
}
