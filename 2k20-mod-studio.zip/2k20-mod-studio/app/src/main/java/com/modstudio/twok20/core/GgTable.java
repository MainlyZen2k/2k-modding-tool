package com.modstudio.twok20.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * GameGuardian saved-table (.txt) reader / writer - byte-compatible with the
 * tables used by the 2K20 mobile modding community (the user's uploads like
 * "Ball", "76ers", "jersey texture" use exactly this format).
 *
 * Line layout:
 *   Var #LABEL|ADDR|TYPE|HEXVALUE|0|0|0|0|PERM|MAP_PATH|MAP_OFFSET
 *
 * TYPE codes as used by GG saves: 1=byte(1) 2=word(2) 4=dword(4) 10=float(4)
 * Float hex values are shown big-endian (e.g. 40800000 = 4.0f).
 */
public final class GgTable {

    public static class Entry {
        public String label = "";
        public long addr;
        public String type = "dword"; // byte | word | dword | float
        public int size = 4;
        public long intValue;
        public float floatValue;
        public String perm = "";
        public String path = "";
        public Long offset; // hex offset within mapped lib
        public String region = "unmapped"; // lib_code | lib_bss | lib_data | heap | unmapped | other

        public String typeName() { return type; }
        public int typeCode() {
            if ("byte".equals(type)) return 1;
            if ("word".equals(type)) return 2;
            if ("float".equals(type)) return 10;
            return 4;
        }
        public String valueDisplay() {
            if ("float".equals(type)) return Float.toString(floatValue);
            return Long.toString(intValue);
        }
        public String valueHex() {
            if ("float".equals(type)) {
                return String.format("%08x", Float.floatToIntBits(floatValue));
            }
            return Long.toHexString(intValue);
        }
        public void setFromDisplay(String s) throws NumberFormatException {
            s = s.trim();
            if ("float".equals(type)) {
                floatValue = Float.parseFloat(s);
            } else {
                if (s.startsWith("0x") || s.startsWith("0X")) {
                    intValue = Long.parseLong(s.substring(2), 16);
                } else {
                    boolean hexLike = !s.isEmpty() && !s.startsWith("-")
                            && s.matches("[0-9a-fA-F]+")
                            && s.length() >= 2 && containsLetter(s);
                    intValue = Long.parseLong(s, hexLike ? 16 : 10);
                }
            }
        }
        private static boolean containsLetter(String s) {
            for (char c : s.toCharArray())
                if ((c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')) return true;
            return false;
        }
    }

    private static final Charset UTF8 = Charset.forName("UTF-8");

    public static List<Entry> parse(File f) throws IOException {
        List<Entry> out = new ArrayList<Entry>();
        BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(f), UTF8));
        try {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                Entry e = parseLine(line);
                if (e != null) out.add(e);
            }
        } finally {
            try { r.close(); } catch (IOException ignored) {}
        }
        return out;
    }

    /** Parse one line; returns null for non-table lines (save-slot numbers etc). */
    public static Entry parseLine(String line) {
        String[] f = line.split("\\|");
        if (f.length < 4) return null;
        String label = f[0];
        boolean autoNamed = false;
        if (label.startsWith("Var #")) {
            label = label.substring(5);
            autoNamed = true;
        }
        long addr;
        try {
            addr = Long.parseLong(f[1].trim(), 16);
        } catch (NumberFormatException nfe) {
            return null;
        }
        int tcode;
        try {
            tcode = Integer.parseInt(f[2].trim());
        } catch (NumberFormatException nfe) {
            return null;
        }
        String hex = (f[3] == null ? "" : f[3].trim().toLowerCase());
        if (hex.isEmpty() || !hex.matches("[0-9a-f]+")) return null;
        Entry e = new Entry();
        e.label = label;
        e.addr = addr;
        switch (tcode) {
            case 1: e.type = "byte"; e.size = 1; break;
            case 2: e.type = "word"; e.size = 2; break;
            case 4: e.type = "dword"; e.size = 4; break;
            case 10: e.type = "float"; e.size = 4; break;
            default: return null;
        }
        if ("float".equals(e.type)) {
            try {
                int bits = (int) Long.parseLong(padHex(hex, 8), 16);
                e.floatValue = Float.intBitsToFloat(bits);
            } catch (NumberFormatException nfe) {
                return null;
            }
        } else {
            e.intValue = Long.parseLong(hex, 16);
        }
        e.perm = f.length > 8 ? f[8] : "";
        e.path = f.length > 9 ? f[9] : "";
        String off = f.length > 10 ? f[10] : "";
        if (!off.isEmpty() && off.matches("[0-9a-fA-F]+")) {
            try {
                e.offset = Long.parseLong(off, 16);
            } catch (NumberFormatException ignored) {}
        }
        classify(e);
        if (autoNamed && e.label.equalsIgnoreCase(Long.toHexString(e.addr))) {
            // keep label as-is; it is the auto address-name GG assigned
        }
        return e;
    }

    private static String padHex(String s, int n) {
        while (s.length() < n) s = "0" + s;
        return s;
    }

    private static void classify(Entry e) {
        String p = e.path == null ? "" : e.path;
        if (p.contains("libnba2k20")) {
            if (p.contains(":bss")) e.region = "lib_bss";
            else if (e.perm != null && e.perm.contains("x")) e.region = "lib_code";
            else e.region = "lib_data";
        } else if (p.contains("libc_malloc")) {
            e.region = "heap";
        } else if (p.isEmpty()) {
            e.region = "unmapped";
        } else {
            e.region = "other";
        }
    }

    /** Write entries back in GameGuardian save-table format. */
    public static String write(List<Entry> entries) {
        StringBuilder sb = new StringBuilder();
        for (Entry e : entries) {
            String labelField;
            if (e.label.startsWith("Var #")) {
                labelField = e.label;
            } else {
                labelField = e.label;
            }
            sb.append(labelField)
              .append('|').append(Long.toHexString(e.addr))
              .append('|').append(e.typeCode())
              .append('|').append(e.valueHex())
              .append("|0|0|0|0|")
              .append(e.perm == null ? "" : e.perm)
              .append('|').append(e.path == null ? "" : e.path)
              .append('|').append(e.offset == null ? "0" : Long.toHexString(e.offset))
              .append('\n');
        }
        return sb.toString();
    }

    public static boolean save(File out, List<Entry> entries) {
        try {
            OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(out), UTF8);
            w.write(write(entries));
            w.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /** Stability note used by the UI. */
    public static String stabilityNote(Entry e) {
        if ("heap".equals(e.region)) return "heap address - device/session specific, usually unstable";
        if ("unmapped".equals(e.region)) return "no mapping info saved - check the address before applying";
        if ("lib_code".equals(e.region)) return "code-section patch - game must be idle, offline only";
        if ("lib_bss".equals(e.region)) return "live data offset - game version dependent (98.0.2 lib)";
        return "";
    }
}
