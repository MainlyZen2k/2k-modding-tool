package com.modstudio.twok20.core;

import android.content.Context;
import android.content.res.AssetManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Loads the built-in patch catalog (assets/patch_catalog.json) generated from
 * the community GameGuardian tables (Ball, 76ers, jersey texture, Xiao Ke
 * greenlight, Xue Wangjia ball color). Provides grouped, editable entries.
 */
public final class PatchCatalog {

    public static class Entry {
        public String label;
        public String labelEn;
        public String type;      // byte|word|dword|float
        public String offsetHex; // null when unknown
        public String region;
        public String valueHex;
        public long intValue;
        public float floatValue;
        public boolean isFloat;
        public String addrHex;   // original GG address (hex string, no 0x)
        public String perm;      // r-xp / rw-p
        public String path;      // original map path (device-specific)

        /** Original GameGuardian address as hex string. */
        public String addrHex() { return addrHex == null || addrHex.isEmpty() ? "0" : addrHex; }
        /** Original /proc/self/maps path for GG table export. */
        public String libPath() {
            if (path != null && !path.isEmpty()) return path;
            if ("lib_bss".equals(region)) return "/data/app/com.t2ksports.nba2k20and/lib/arm64/libnba2k20_clean_opt.so:bss";
            if ("lib_code".equals(region) || "lib_data".equals(region))
                return "/data/app/com.t2ksports.nba2k20and/lib/arm64/libnba2k20_clean_opt.so";
            return "";
        }
        public String valueDisplay() { return isFloat ? Float.toString(floatValue) : Long.toString(intValue); }
        public String title() {
            if (labelEn != null && !labelEn.isEmpty()) return labelEn;
            return label;
        }
        public String subtitle() {
            String base = (labelEn != null && !labelEn.isEmpty() && !label.equals(labelEn)) ? label : "";
            return base + (base.isEmpty() ? "" : " - ") + type + " @ 0x"
                    + (offsetHex == null ? "?" : offsetHex) + "  [" + region + "]";
        }
    }

    public static class Group {
        public String id;
        public String title;
        public List<Entry> entries = new ArrayList<Entry>();
    }

    public static class Table {
        public String id;
        public String title;
        public String author;
        public String category;
        public String note;
        public List<Group> groups = new ArrayList<Group>();
        public int entryCount() {
            int n = 0;
            for (Group g : groups) n += g.entries.size();
            return n;
        }
    }

    public static class Catalog {
        public String gamePackage = "com.t2ksports.nba2k20and";
        public String gameLib = "libnba2k20_clean_opt.so";
        public String gameVersion = "";
        public List<Table> tables = new ArrayList<Table>();

        public Table byId(String id) {
            for (Table t : tables) if (t.id.equals(id)) return t;
            return null;
        }
    }

    private static Catalog cached;

    public static synchronized Catalog get(Context ctx) {
        if (cached != null) return cached;
        try {
            AssetManager am = ctx.getAssets();
            InputStream is = am.open("patch_catalog.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            is.close();
            String json = new String(bo.toByteArray(), Charset.forName("UTF-8"));
            cached = parse(json);
        } catch (Exception e) {
            cached = new Catalog(); // empty
        }
        return cached;
    }

    static Catalog parse(String json) throws Exception {
        Catalog cat = new Catalog();
        JSONObject root = new JSONObject(json);
        JSONObject game = root.optJSONObject("game");
        if (game != null) {
            cat.gamePackage = game.optString("package", cat.gamePackage);
            cat.gameLib = game.optString("lib", cat.gameLib);
            cat.gameVersion = game.optString("version", "");
        }
        JSONArray tables = root.getJSONArray("tables");
        for (int t = 0; t < tables.length(); t++) {
            JSONObject jt = tables.getJSONObject(t);
            Table tb = new Table();
            tb.id = jt.getString("id");
            tb.title = jt.getString("title");
            tb.author = jt.optString("author", "");
            tb.category = jt.optString("category", "");
            tb.note = jt.optString("note", "");
            JSONArray groups = jt.optJSONArray("groups");
            if (groups == null) continue;
            for (int g = 0; g < groups.length(); g++) {
                JSONObject jg = groups.getJSONObject(g);
                Group gr = new Group();
                gr.id = jg.getString("id");
                gr.title = jg.getString("title");
                JSONArray je = jg.getJSONArray("entries");
                for (int i = 0; i < je.length(); i++) {
                    JSONObject je2 = je.getJSONObject(i);
                    Entry e = new Entry();
                    e.label = je2.optString("label", "");
                    e.labelEn = je2.optString("label_en", "");
                    e.type = je2.optString("type", "dword");
                    e.offsetHex = je2.has("offset") && !je2.isNull("offset")
                            ? je2.getString("offset") : null;
                    e.region = je2.optString("region", "unmapped");
                    e.valueHex = je2.optString("value_hex", "0");
                    e.isFloat = "float".equals(e.type);
                    if (e.isFloat) e.floatValue = (float) je2.optDouble("value", 0);
                    else e.intValue = je2.optLong("value", 0);
                    e.addrHex = je2.optString("addr", "");
                    e.perm = je2.optString("perm", "");
                    e.path = je2.optString("path", "");
                    gr.entries.add(e);
                }
                if (!gr.entries.isEmpty()) tb.groups.add(gr);
            }
            cat.tables.add(tb);
        }
        return cat;
    }

    private PatchCatalog() {}
}
