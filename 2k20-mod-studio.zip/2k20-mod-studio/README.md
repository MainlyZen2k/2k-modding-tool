# 2K20 Mod Studio

A personal modding tool APK for **NBA 2K20 mobile (Android)**, built from the
workflow of the 2K20 mobile modding community (the "modded 2K27" APK builders,
Xiao Ke, Xue Wangjia, DAN2K, Sebastian2k and the Facebook/YouTube scene).

It works on the community formats directly:

- **IFF-style asset containers** - signature-sniffing for embedded DDS
  textures, Ogg/WAV/Wwise audio payloads (same-size swap keeps containers valid)
- **GameGuardian saved tables** - the `Var #name|addr|type|value` format the
  scene shares (your `Ball`, `76ers`, `jersey texture`, Xiao Ke, Xue Wangjia
  tables are pre-built into the app catalog)
- **Advanced Features patch profiles** - `name|0xoffset|type|value`, the
  format injected loader libs apply at game launch

## Modules

| Module | What it does |
| --- | --- |
| Texture Studio | Open IFF/DDS, list embedded textures, retexture PNG -> DDS with Original / HD 1024 / High HD 2048 / Ultra HD 4096 presets, flip for face porting, mipmaps, same-size container swap |
| Audio Swap | Find Ogg/WAV/WEM payloads, extract + preview (MediaPlayer), byte-swap equal-or-smaller replacement |
| Player Editor | The full live player structure from the Ball table: identity, gear, animations, 40+ attributes, all tendencies, badge bitmasks, face block, team code, quarter length, difficulty, game speed |
| Patch Lab | Convert GG tables <-> Advanced Features profiles, stability warnings (heap / BSS / code), built-in catalog of all 5 community tables |
| Repack Guide | In-app checklist for ApkEditor + MT Manager repackage & signing |
| Help & Legal | Workflows, Android 11+ storage notes, troubleshooting, fair-use rules |

Output goes to `/storage/emulated/0/ModStudio/{Output,Extracted,patches}`.

## Build the APK with GitHub Actions (no PC needed)

1. Create a GitHub account and a new repository (e.g. `2k20-mod-studio`).
2. Upload this whole folder (keep `.github/workflows/build.yml`).
3. Open the **Actions** tab -> **Build APK** workflow -> run it (or just push).
4. Download the artifact `modstudio-debug-apk` (or release) -> install on your phone
   (allow unknown sources). Sign the release APK with MT Manager if you want a
   consistent signature.

The project uses zero external dependencies (pure Android SDK, Java), so it
also opens in AIDE on-device if you prefer.

## Project layout

```
app/src/main/java/com/modstudio/twok20/
  core/   DdsCodec, IffSniffer, IffPatch, GgTable, PatchProfile, PatchCatalog, FileDirs
  ui/     MainActivity, TextureActivity, AudioActivity, PlayerEditorActivity,
          PatchActivity, GuideActivity, FilePickerActivity, CommonUi
app/src/main/assets/patch_catalog.json   311 entries from the 5 community tables
docs/native/modloader.cpp                reference Advanced Features loader
```

## Verified core

- GG table parser round-trips the community tables (float `40800000` = 4.0,
  dword `2745b60` = $41,180,000 salary, byte/word/dword regions all correct)
- DDS codec: DXT1 / DXT3 / DXT5 / RGBA8 decode+encode validated by a JVM test
  suite (35 checks) - RGBA8 exact, DXT1 mean error < 7, DXT5 alpha mean < 3

## Fair use

Personal, offline customization of a game you own. Never distribute repacked
APKs or 2K assets, never use patches online. See the in-app Help screen.
